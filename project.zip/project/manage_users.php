<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

include 'includes/config.php';

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']); 
    $conn->query("DELETE FROM users WHERE User_ID=$id");
    header("Location: manage_users.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users - Furniture Shop</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <link rel="stylesheet" href="css/admin_sidebar.css">
    <link rel="stylesheet" href="css/admin.css">
    
    <script src="js/admin_script.js" defer></script>
</head>
<body class="bg-light">

<?php include 'admin_sidebar.php'; ?>

<div class="main-content p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-dark">Manage Users</h2>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white py-3">
            <h5 class="mb-0 fw-bold text-secondary"><i class="bi bi-person-lines-fill"></i> Customer Overview</h5>
        </div>
        
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th class="py-3 ps-4">ID</th>
                            <th class="py-3">Username</th>
                            <th class="py-3">Email</th>
                            <th class="py-3">Role</th> 
                            <th class="py-3 text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT * FROM users WHERE role='customer'");
                        
                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td class='ps-4 fw-bold'>#{$row['User_ID']}</td>
                                        <td>
                                            <div class='fw-bold'>{$row['User_Name']}</div>
                                        </td>
                                        <td>{$row['email']}</td>
                                        <td><span class='badge bg-info text-dark'>{$row['role']}</span></td>
                                        <td class='text-end pe-4'>
                                            <a href='manage_users.php?delete={$row['User_ID']}' onclick=\"return confirm('Are you sure you want to delete this user?');\" class='btn btn-sm btn-outline-danger'>
                                                <i class='bi bi-trash3-fill'></i> Delete
                                            </a>
                                        </td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center py-5 text-muted'>No customers found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

</body>
</html>