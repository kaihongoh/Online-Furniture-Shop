<?php
session_start();
include 'includes/config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Error handling
    if (empty($username) || empty($password)) {
        echo "<script>alert('All fields are required.'); window.history.back();</script>";
        exit;
    }

    // Check against admin_users table (NOT users table)
    $stmt = $conn->prepare(
        "SELECT admin_id, username, password, full_name, role, is_active 
         FROM admin_users 
         WHERE username = ? AND is_active = TRUE"
    );
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $admin = $result->fetch_assoc();

        // For plain text passwords (change to password_verify() if using hashed passwords)
        if ($password === $admin['password']) {
            // Set Admin Specific Sessions - INCLUDING ROLE
            $_SESSION['admin_id'] = $admin['admin_id'];
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_name'] = $admin['full_name'];
            $_SESSION['admin_role'] = $admin['role']; // THIS LINE IS CRITICAL
            $_SESSION['admin_logged_in'] = true;
            
            // Update last login time
            $update_stmt = $conn->prepare("UPDATE admin_users SET last_login = NOW() WHERE admin_id = ?");
            $update_stmt->bind_param("s", $admin['admin_id']);
            $update_stmt->execute();
            $update_stmt->close();
            
            header("Location: admin_dashboard.php");
            exit;
        } else {
            echo "<script>alert('Invalid Admin credentials.'); window.history.back();</script>";
            exit;
        }
    } else {
        echo "<script>alert('Administrator account not found.'); window.history.back();</script>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Access - Ikea4U</title>
    <link rel="stylesheet" href="css/template.css">
    <link rel="stylesheet" href="css/admin_login.css">
        <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body>
    <section class="login-page">
        <div class="login-container">
            <div class="login-welcome admin-welcome">
                <div class="admin-badge">ADMIN PORTAL</div>
                <h2>Authorized Personnel Only</h2>
                <p>Welcome to the Ikea4U backend management system. Access here is restricted to staff members only.</p>
                <ul class="admin-checklist">
                    <li><i class="bi bi-graph-up"></i> Manage Sales & Revenue</li>
                    <li><i class="bi bi-box-seam"></i> Inventory Control</li>
                    <li><i class="bi bi-people"></i> User Management</li>
                </ul>
            </div>

            <div class="login-form-container admin-form-container">
                <div class="form-header admin-form-header">
                    <h1>Admin Login</h1>
                    <p>Enter your staff credentials</p>
                </div>

                <form class="login-form admin-login-form" action="" method="POST">
                    <div class="form-group">
                        <label for="username" class="form-label">Admin Username:</label>
                        <input type="text" id="username" name="username" class="form-control" placeholder="Username" required>
                    </div>

                    <div class="form-group">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required>
                    </div>

                    <button type="submit" class="btn-login admin-btn-login">Verify Identity</button>
                </form>

                <div class="form-footer admin-form-footer">
                    <a href="login.php">
                        <i class="bi bi-arrow-left"></i> Return to Customer Login
                    </a>
                </div>
            </div>
        </div>
    </section>
</body>
</html>