<?php
session_start();

// Simple admin check - one line
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

include 'includes/config.php';

// 1. FETCH STATS - FIXED TODAY'S SALES QUERY
$sql_stats = "SELECT 
    COUNT(*) as total_orders,
    SUM(CASE WHEN Order_Status = 'Pending' THEN 1 ELSE 0 END) as pending_orders,
    SUM(CASE WHEN Order_Status = 'Completed' THEN Total_Amount ELSE 0 END) as total_revenue,
    SUM(CASE WHEN Order_Status = 'Completed' AND DATE(Order_Date) = CURDATE() THEN Total_Amount ELSE 0 END) as today_sales
FROM orders";

$stats = $conn->query($sql_stats)->fetch_assoc();

// Debug: Check what the query returns
// echo "<pre>"; print_r($stats); echo "</pre>";

$total_revenue = $stats['total_revenue'] ?? 0;
$today_sales   = $stats['today_sales'] ?? 0;
$total_orders  = $stats['total_orders'] ?? 0;
$pending       = $stats['pending_orders'] ?? 0;

// If today_sales is NULL, set it to 0
if ($today_sales === null) {
    $today_sales = 0;
}

$cards = [
    ['title' => "Today's Sales", 'value' => 'RM ' . number_format($today_sales, 2), 'icon' => 'lightning-charge-fill', 'color' => 'info'],
    ['title' => "Total Balance", 'value' => 'RM ' . number_format($total_revenue, 2), 'icon' => 'cash-stack', 'color' => 'success'],
    ['title' => "Total Orders",  'value' => $total_orders, 'icon' => 'cart-fill', 'color' => 'primary'],
    ['title' => "Pending Orders",'value' => $pending, 'icon' => 'clock-history', 'color' => 'warning']
];

// 2. GRAPH DATA (Status & Sales)
$status_labels = []; $status_data = [];
$res = $conn->query("SELECT Order_Status, COUNT(*) as count FROM orders GROUP BY Order_Status");
while($row = $res->fetch_assoc()) {
    $status_labels[] = $row['Order_Status'];
    $status_data[] = $row['count'];
}

$sales_dates = []; $sales_amounts = []; $running_total = 0;
$res = $conn->query("SELECT DATE_FORMAT(Order_Date, '%d-%b') as nice_date, SUM(Total_Amount) as daily_total 
                     FROM orders WHERE Order_Status = 'Completed' 
                     GROUP BY DATE(Order_Date) ORDER BY Order_Date ASC");
while($row = $res->fetch_assoc()) {
    $sales_dates[] = $row['nice_date'];
    $running_total += $row['daily_total'];
    $sales_amounts[] = $running_total;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Ikea4U</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/admindashboard.css">
    <link rel="stylesheet" href="css/admin_sidebar.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>
<body>
        <?php include 'admin_sidebar.php'; ?>

    <main class="main-content p-4">
        <h2 class="fw-bold mb-4">Dashboard Overview</h2>
        
        <div class="row g-4 mb-4">
            <?php foreach($cards as $c): ?>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm p-3">
                    <div class="text-<?php echo $c['color']; ?> fs-3 mb-2"><i class="bi bi-<?php echo $c['icon']; ?>"></i></div>
                    <h6 class="text-muted small"><?php echo $c['title']; ?></h6>
                    <h4 class="fw-bold"><?php echo $c['value']; ?></h4>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="row g-4">
            <div class="col-md-8">
                <div class="card border-0 shadow-sm p-4">
                    <h5 class="fw-bold mb-3">Revenue Growth</h5>
                    <canvas id="salesChart" height="300"></canvas>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-4">
                    <h5 class="fw-bold mb-3">Order Distribution</h5>
                    <canvas id="statusChart" height="300"></canvas>
                </div>
            </div>
        </div>
    </main>



    <script>
        //Line Chart
        const salesDates = <?php echo json_encode($sales_dates); ?>;
        const salesAmounts = <?php echo json_encode($sales_amounts); ?>;
        new Chart(document.getElementById('salesChart'), {
        type: 'line',
         data: {
            labels: salesDates,
            datasets: [{ data: salesAmounts, borderColor: '#0058a3', fill: true, tension: 0.3 }]
        },
        options: {
        plugins: {
            legend: {
                display: false
            }
        }
    }
    });
                // Order Distribution Pie Chart
        new Chart(document.getElementById('statusChart'), {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($status_labels); ?>,
                datasets: [{ data: <?php echo json_encode($status_data); ?>, backgroundColor: ['#ffc107', '#0d6efd', '#198754', '#dc3545'] }]
            }
        });
    </script>
</body>
</html>