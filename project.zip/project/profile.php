<?php
session_start();
include 'includes/config.php';

if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Please login first!'); window.location.href='home.php';</script>";
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";
$error = "";

$malaysia_states = [
    "Johor", "Kedah", "Kelantan", "Melaka", "Negeri Sembilan", 
    "Pahang", "Perak", "Perlis", "Pulau Pinang", "Sabah", 
    "Sarawak", "Selangor", "Terengganu", 
    "W.P. Kuala Lumpur", "W.P. Labuan", "W.P. Putrajaya"
];

if (isset($_POST['save_changes'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $postcode = mysqli_real_escape_string($conn, $_POST['postcode']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);

    if (!preg_match("/^\d{3}-\d{3}-\d{4}$/", $phone)) {
        $error = "Error: Phone number must be in format 000-000-0000";
    } 

    elseif (!preg_match("/^\d{5}$/", $postcode)) {
        $error = "Error: Postcode must be exactly 5 digits.";
    } 
    else {
        // 1. Check if Email is already taken by another user
        $check_email = "SELECT User_ID FROM users WHERE email = '$email' AND User_ID != '$user_id'";
        $result_email = mysqli_query($conn, $check_email);

        // 2. Check if Phone Number is already taken by another user
        $check_phone = "SELECT User_ID FROM users WHERE phoneNumber = '$phone' AND User_ID != '$user_id'";
        $result_phone = mysqli_query($conn, $check_phone);

        if (mysqli_num_rows($result_email) > 0) {
            $error = "Error: This email is already registered by another user.";
        } elseif (mysqli_num_rows($result_phone) > 0) {
            $error = "Error: This phone number is already registered by another user.";
        } else {
            // No duplicates found, proceed with update
            $update_sql = "UPDATE users SET 
                           email='$email', 
                           phoneNumber='$phone', 
                           state='$state', 
                           postcode='$postcode', 
                           address='$address' 
                           WHERE User_ID='$user_id'";

            if (mysqli_query($conn, $update_sql)) {
                $message = "Profile updated successfully!";
            } else {
                $error = "Database Error: " . mysqli_error($conn);
            }
        }
    }
}

$sql = "SELECT * FROM users WHERE User_ID = '$user_id'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

if (!$user) {
    session_destroy();
    die("User not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile</title>
    <link rel="stylesheet" href="css/template.css">
    <style>
        .profile-container {
            margin:50px auto;
            background: white; padding: 40px; border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05); max-width: 800px;
        }
        .profile-header {
            border-bottom: 2px solid #f4f4f4; padding-bottom: 20px; margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
            position: relative; 
        }
        .form-group label {
            text-align:left; display: block; font-weight: bold; color: #555; margin-bottom: 8px;
        }
        .form-control {
            width: 100%; padding: 12px; border: 1px solid #ccc; border-radius: 6px;
            font-size: 16px; box-sizing: border-box; background-color: #fff;
            transition: border-color 0.3s;
        }
        .form-control[readonly] {
            background-color: #f9f9f9; color: #777; cursor: not-allowed;
        }

        select.form-control {
            height: 45px;
            cursor: pointer;
        }

        .change-link {
            position: absolute; right: 10px; top: 38px;
            color: #007bff; text-decoration: none; font-size: 14px; font-weight: bold;
            cursor: pointer; background: none; border: none;
        }
        .change-link:hover { text-decoration: underline; }

        .btn-save {
            background-color: #ee4d2d;
            color: white; padding: 12px 30px; border: none; border-radius: 4px;
            cursor: pointer; font-size: 16px; margin-top: 20px;
        }
        .btn-save:hover { background-color: #d73211; }

        .alert { padding: 15px; margin-bottom: 20px; border-radius: 4px; }
        .alert-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>

       <?php include 'includes/header.php'; ?>

    <div class="dashboard-container">


        <main class="main-content">
            <div class="profile-container">
                
                <div class="profile-header">
                    <h2>My Profile</h2>
                    <p>Manage and protect your account</p>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo $message; ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-error"><?php echo $error; ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    
                    <div class="form-group">
                        <label>Username</label>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['User_Name']); ?>" readonly>
                        <small style="color:#999;">Username cannot be changed.</small>
                    </div>

                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" id="emailInput" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" readonly required>
                        <button type="button" class="change-link" onclick="enableEdit('emailInput')">Change</button>
                    </div>

                    <div class="form-group">
                        <label>Phone Number (Format: 000-000-0000)</label>
                        <input type="text" 
                               name="phone" 
                               id="phoneInput" 
                               class="form-control" 
                               value="<?php echo htmlspecialchars($user['phoneNumber']); ?>" 
                               placeholder="000-000-0000"
                               maxlength="12"
                               oninput="formatPhoneNumber(this)"
                               readonly required>
                        <button type="button" class="change-link" onclick="enableEdit('phoneInput')">Change</button>
                    </div>

                    <div style="display:flex; gap:10px;">
                        <div class="form-group" style="flex:1;">
                            <label>State</label>
                            <select name="state" class="form-control" required>
                                <option value="">Select State</option>
                                <?php 
                                foreach ($malaysia_states as $state_name) {
             
                                    $selected = ($user['state'] == $state_name) ? 'selected' : '';
                                    echo "<option value='$state_name' $selected>$state_name</option>";
                                } 
                                ?>
                            </select>
                        </div>

                        <div class="form-group" style="flex:1;">
                            <label>Postcode</label>
                            <input type="text" 
                                   name="postcode" 
                                   class="form-control" 
                                   value="<?php echo htmlspecialchars($user['postcode']); ?>" 
                                   placeholder="Postcode"
                                   maxlength="5" 
                                   pattern="\d{5}"
                                   title="Postcode must be exactly 5 digits"
                                   oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 5);"
                                   required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Full Address</label>
                        <textarea name="address" class="form-control" rows="3" placeholder="Enter your full address"><?php echo htmlspecialchars($user['address']); ?></textarea>
                    </div>

                    <button type="submit" name="save_changes" class="btn-save">Save</button>
                </form>

            </div>
        </main>
    </div>

    <script>
        function enableEdit(inputId) {
            var input = document.getElementById(inputId);
            if (input.hasAttribute('readonly')) {
                input.removeAttribute('readonly');
                input.focus();
                input.style.backgroundColor = "#fff"; 
                input.style.color = "#333";
            }
        }

        function formatPhoneNumber(input) {
            let value = input.value.replace(/\D/g, '');
            if (value.length > 10) value = value.substring(0, 10);
            if (value.length > 6) {
                input.value = value.slice(0, 3) + '-' + value.slice(3, 6) + '-' + value.slice(6);
            } else if (value.length > 3) {
                input.value = value.slice(0, 3) + '-' + value.slice(3);
            } else {
                input.value = value;
            }
        }
    </script>
<?php include 'includes/footer.php'; ?>
</body>
</html>



