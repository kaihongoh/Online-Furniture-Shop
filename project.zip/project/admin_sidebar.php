<nav class="sidebar">
    <div class="sidebar-brand"><i class="bi bi-shop"></i> Ikea4U Admin</div>
    <div class="d-flex flex-column">
        <div class="sidebar-heading">Main</div>
        
        <?php
        // Get current filename to set active class
        $current_page = basename($_SERVER['PHP_SELF']);
        ?>

        <a href="admin_dashboard.php" class="nav-link <?php echo ($current_page == 'admin_dashboard.php') ? 'active' : ''; ?>">
            <i class="bi bi-grid-1x2-fill"></i> Dashboard
        </a>

        <a href="manage_users.php" class="nav-link <?php echo ($current_page == 'manage_users.php') ? 'active' : ''; ?>">
            <i class="bi bi-people-fill"></i> Manage User
        </a>
        
        <a href="manage_orders.php" class="nav-link <?php echo ($current_page == 'manage_orders.php') ? 'active' : ''; ?>">
            <i class="bi bi-receipt"></i> Manage Orders
        </a>
        
        <a href="manage_category.php" class="nav-link <?php echo ($current_page == 'manage_category.php') ? 'active' : ''; ?>">
            <i class="bi bi-layers-fill"></i> Manage Category
        </a>

        <a href="product.php" class="nav-link <?php echo ($current_page == 'AddProduct.php' || $current_page == 'product.php' || $current_page == 'EditProduct.php') ? 'active' : ''; ?>">
            <i class="bi bi-box-seam"></i>Manage Product
        </a>

            <?php if (isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'super_admin'): ?>
        <a href="manage_admins.php" class="nav-link <?php echo ($current_page == 'manage_admins.php') ? 'active' : ''; ?>">
            <i class="bi bi-shield-lock"></i>
            <span>Manage Admins</span>
        </a>
        <?php endif; ?>
        
        <div class="sidebar-heading mt-2">Account</div>
        <a href="admin_logout.php" class="nav-link text-danger">
         <i class="bi bi-box-arrow-right"></i> Logout
        </a>
    </div>

</nav>