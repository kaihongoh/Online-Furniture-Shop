<?php
require_once 'includes/config.php';
session_start();

// Check if ID is provided (when type from browser), if error will redirect back to product list
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: product.php");
    exit();
}

$id = intval($_GET['id']);

// fetch product data
$product = null;
$stmt = $conn->prepare("SELECT * FROM product WHERE Product_ID = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: product.php");
    exit();
}

$product = $result->fetch_assoc();
$stmt->close();

// fetch categories for dropdown
$categories = [];
$categoryResult = $conn->query("SELECT * FROM category ORDER BY Category_Name");
while ($row = $categoryResult->fetch_assoc()) {
    $categories[] = $row;
}

// handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // get form data
    $name = trim($_POST['name']);
    $category_id = intval($_POST['category_id']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $description = trim($_POST['description']);
    
    //error array
    $errors=[];
// validation for edit
    if (empty($name)) {
        $errors[] = "Product name is required";
    } else {
        // check if product name already exists (exclude current product)
        $check_stmt = $conn->prepare("SELECT Product_ID FROM product WHERE Product_Name = ? AND Product_ID != ?");
        $check_stmt->bind_param("si", $name, $id);
        $check_stmt->execute();
        $check_stmt->store_result();
        
        if ($check_stmt->num_rows > 0) {
            $errors[] = "Product name already exists. Please choose a different name.";
        }
        $check_stmt->close();
    }
    
    if ($category_id <= 0) {
        $errors[] = "Please select a category";
    }
    
    if (empty($price) || $price <= 0) {
        $errors[] = "Please provide a valid price";
    }
    
    if ($stock < 0) {
        $errors[] = "Stock quantity cannot be negative";
    }

    //if dont have file uploads/products, then create uploads/products
    $upload_dir = 'uploads/products';

    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // handle image upload
    $image_name = $product['Product_Picture']; // Keep existing by default
    
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/avif'];
        $file_type = $_FILES['image']['type'];
        $file_size = $_FILES['image']['size'];

        //validate the size and type of the file
        if (!in_array($file_type, $allowed_types)) {
            $errors[] = "Only JPG, PNG, GIF and AVIF files are allowed";
        } else if ($file_size > 2 * 1024 * 1024) {
            $errors[] = "Image size must be less than 2MB";
        } else { //no error then can upload
            $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $image_name = uniqid() . '.' . $file_extension;
            $upload_path = 'uploads/products/' . $image_name;

            // upload the file (directory must already exist)
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                // Delete old image if exists
                if (!empty($product['Product_Picture'])) {
                    $old_image = 'uploads/products/' . $product['Product_Picture'];
                    if (file_exists($old_image)) {
                        unlink($old_image);
                    }
                }
            } else {
                $errors[] = "Failed to upload image";
                $image_name = $product['Product_Picture'];
            }
        }                  
    }

    
    // if no error then update product in database
    if (empty($errors)){
    $update_stmt = $conn->prepare("UPDATE product SET 
        Product_Name = ?, 
        Category_ID = ?, 
        Product_Price = ?, 
        Product_Stock = ?, 
        Product_Description = ?, 
        Product_Picture = ? 
        WHERE Product_ID = ?");
    
    $update_stmt->bind_param("sidissi", 
        $name, 
        $category_id, 
        $price, 
        $stock, 
        $description, 
        $image_name, 
        $id
    );
    
    if ($update_stmt->execute()) {
        $_SESSION['update_success'] = true;
        $_SESSION['update_message'] = "Product updated successfully!";
        header("Location: EditProduct.php?id=" . $id);
        exit();
    } else {
    $errors[] = "Failed to update product: " . $conn->error;
    }
    
    $update_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Lakeshow Grocery</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/admin_sidebar.css">
    <link rel="stylesheet" href="css/EditProduct.css">

</head>
<body>
    <?php include_once 'admin_sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <h1>Edit Product</h1>
        </div>

        <div class="content-wrapper">
            <div class="action-bar">
                <a href="product.php" class="btn btn-secondary btn-large"> Back to Products</a>
            </div>

            <?php if (isset($_SESSION['update_success']) && $_SESSION['update_success']): ?>
                <div class="alert alert-success" id="successAlert">
                    <span><?php echo $_SESSION['update_message']; ?></span>
                </div>
                <?php 
                unset($_SESSION['update_success']);
                unset($_SESSION['update_message']);
                ?>
            <?php endif; ?>
                    <!--show the error if product name is repeat-->
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="form-container">
                
                <form action="EditProduct.php?id=<?php echo $id; ?>" method="POST" enctype="multipart/form-data" id="editForm" novalidate>
                    <div class="form-section">
                        
                        
                        <div class="form-group">
                            <label for="name">Product Name <span class="required">*</span></label>
                            <input type="text" id="name" name="name" 
                                   value="<?php echo htmlspecialchars(isset($_POST['name']) ? $_POST['name'] : $product['Product_Name']); ?>" 
                                   required placeholder="Enter product name">
                        </div>

                        <div class="form-group">
                            <label for="category_id">Category <span class="required">*</span></label>
                            <select id="category_id" name="category_id" required>
                                <option value="">Select Category</option>
                                <?php 
                                $selectedCategory = isset($_POST['category_id']) ? $_POST['category_id'] : $product['Category_ID'];
                                foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['Category_ID']; ?>" 
                                        <?php echo ($category['Category_ID'] == $selectedCategory) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['Category_Name']); ?>
                                    </option>
                                <?php endforeach; ?>
                        </select>
                        </div>

                        <div class="form-group">
                            <label for="price">Price (RM) <span class="required">*</span></label>
                            <input type="number" id="price" name="price" step="0.01" min="0.01" 
                                   value="<?php echo isset($_POST['price']) ? htmlspecialchars($_POST['price']) : number_format($product['Product_Price'], 2, '.', ''); ?>"
                                   required placeholder="0.00">
                        </div>

                        <div class="form-group">
                            <label for="stock">Stock Quantity <span class="required">*</span></label>
                            <input type="number" id="stock" name="stock" min="0" 
                                   value="<?php echo isset($_POST['stock']) ? htmlspecialchars($_POST['stock']) : htmlspecialchars($product['Product_Stock']); ?>" 
                                   required placeholder="Enter stock quantity">
                        </div>
                    </div>

                    <div class="form-section">
                        
                        <div class="form-group">
                            <label for="description">Product Description</label>
                            <textarea id="description" name="description" rows="5" 
                                      placeholder="Enter product description..."><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : htmlspecialchars($product['Product_Description']); ?>
                            </textarea>
                                      
                        </div>
                    </div>

                    <div class="form-section">
                        
                        <div class="form-group">
                            <?php if ($product['Product_Picture']): ?>
                                <div class="current-image">
                                    <div><strong>Current Image:</strong> <?php echo htmlspecialchars($product['Product_Picture']); ?></div>
                                    <img src="uploads/products/<?php echo htmlspecialchars($product['Product_Picture']); ?>" 
                                         alt="Current Product Image">
                                </div>
                            <?php else: ?>
                                <div class="current-image">
                                    <div><strong>No image currently set.</strong></div>
                                </div>
                            <?php endif; ?>
                            
                            <label for="image" style="margin-top: 15px;">Upload New Image:</label>
                            <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/gif, image/avif">
                            <small>Maximum file size: 2MB. Allowed formats: JPG, PNG, GIF, AVIF. Leave empty to keep current image.</small>
                            
                            <div id="imagePreviewContainer" style="margin-top: 15px; display: none;">
                                <div><strong>New Image Preview:</strong></div>
                                <img id="imagePreview" style="max-width: 250px; max-height: 250px; margin-top: 10px; border: 1px solid #ddd; border-radius: 6px; padding: 8px;">
                            </div>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" id="submitBtn" class="btn btn-primary btn-large">
                             Update Product
                        </button>
                        <a href="product.php" class="btn btn-secondary btn-large">
                             Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>

        // image preview when new image selected
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const previewContainer = document.getElementById('imagePreviewContainer');
            const previewImage = document.getElementById('imagePreview');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImage.src = e.target.result;
                    previewContainer.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                previewContainer.style.display = 'none';
            }
        });
        
        // show success message only 5 seconds 
        const successAlert = document.getElementById('successAlert');
        if (successAlert) {
            setTimeout(() => {
                successAlert.style.opacity = '0';
                successAlert.style.transition = 'opacity 0.5s';
                setTimeout(() => {
                    successAlert.style.display = 'none';
                }, 500);
            }, 5000);
        }
        

    </script>
</body>
</html>