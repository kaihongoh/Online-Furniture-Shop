<?php
// 开启 Session
session_start();

// 连接数据库
include 'includes/config.php';

// 1. 基础 SQL 语句 (默认查询所有 Active 的产品)
$sql = "SELECT p.*, c.Category_Name FROM product p 
        LEFT JOIN category c ON p.Category_ID = c.Category_ID 
        WHERE p.status = 'Active'";

// --- [修复开始] 添加搜索逻辑 ---
// 如果 Header 传来了 search 参数，就加上筛选条件
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_term = mysqli_real_escape_string($conn, $_GET['search']);
    // 使用 LIKE %...% 进行模糊匹配 (比如搜 'Chair' 能找到 'Armchair')
    $sql .= " AND p.Product_Name LIKE '%$search_term%'";
}
// --- [修复结束] ---

// 2. 处理分类筛选
$cat_id = ""; 
if (isset($_GET['category']) && $_GET['category'] != "") {
    $cat_id = $_GET['category'];
    $sql .= " AND p.Category_ID = '$cat_id'";
}

// 3. 处理排序
$sort = "default"; 
if (isset($_GET['sort'])) {
    $sort = $_GET['sort'];
}

if ($sort == 'price_low') {
    $sql .= " ORDER BY p.Product_Price ASC";
} elseif ($sort == 'price_high') {
    $sql .= " ORDER BY p.Product_Price DESC";
} elseif ($sort == 'newest') {
    $sql .= " ORDER BY p.Product_ID DESC";
} else {
    $sql .= " ORDER BY p.Product_Name ASC";
}

// 执行查询
$result = mysqli_query($conn, $sql);

// 计算找到了多少个商品
$count = mysqli_num_rows($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Furniture Catalogue</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/template.css"> 
    
    <style>
        /* 学生作业风格 CSS */
        body {
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
        }

        .container {
            width: 90%;
            margin: 0 auto;
            padding-top: 20px;
        }

        .toolbar {
            background: white;
            padding: 15px;
            border: 1px solid #ccc;
            margin-bottom: 20px;
            height: 30px;
        }

        .toolbar-left {
            float: left;
            font-size: 16px;
            line-height: 30px;
        }

        .toolbar-right {
            float: right;
        }

        .product-list {
            width: 100%;
        }

        .product-item {
            float: left;
            width: 23%;
            margin: 1%;
            background: white;
            border: 1px solid #ddd;
            padding-bottom: 10px;
            text-align: center;
            box-sizing: border-box;
        }

        .p-image {
            width: 100%;
            height: 200px;
            background-color: #eee;
            border-bottom: 1px solid #ddd;
        }
        
        .p-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .p-info {
            padding: 10px;
        }

        .p-cat {
            font-size: 12px;
            color: gray;
            background: #eee;
            padding: 2px 5px;
            border-radius: 3px;
        }

        .p-name {
            margin: 10px 0;
            font-weight: bold;
            font-size: 16px;
            height: 40px;
            overflow: hidden;
        }

        .p-price {
            color: red;
            font-weight: bold;
            font-size: 18px;
            margin-bottom: 10px;
        }

        .btn {
            display: block;
            background-color: green;
            color: white;
            text-decoration: none;
            padding: 8px;
            border-radius: 4px;
        }

        .btn:hover {
            background-color: darkgreen;
        }

        .clear {
            clear: both;
        }
    </style>
</head>
<body>

<?php include_once 'includes/header.php'; ?>

<div class="container">

    <div class="toolbar">
        <div class="toolbar-left">
            <?php if(isset($_GET['search']) && !empty($_GET['search'])): ?>
                Search Result for "<b><?php echo htmlspecialchars($_GET['search']); ?></b>" - 
            <?php endif; ?>
            Products Found: <b style="color: blue;"><?php echo $count; ?></b>
        </div>

        <div class="toolbar-right">
            <form method="GET" action="catalogue.php">
                <input type="hidden" name="category" value="<?php echo $cat_id; ?>">
                <?php if(isset($_GET['search'])): ?>
                    <input type="hidden" name="search" value="<?php echo htmlspecialchars($_GET['search']); ?>">
                <?php endif; ?>
                
                Sort by: 
                <select name="sort" onchange="this.form.submit()">
                    <option value="default" <?php if($sort=='default') echo 'selected'; ?>>Default</option>
                    <option value="price_low" <?php if($sort=='price_low') echo 'selected'; ?>>Price: Low to High</option>
                    <option value="price_high" <?php if($sort=='price_high') echo 'selected'; ?>>Price: High to Low</option>
                    <option value="newest" <?php if($sort=='newest') echo 'selected'; ?>>Newest Arrivals</option>
                </select>
            </form>
        </div>
    </div>

    <div class="product-list">
        <?php
        if ($count > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $img_path = 'uploads/products/' . $row['Product_Picture'];
        ?>
            <div class="product-item">
                <div class="p-image">
                    <?php if (!empty($row['Product_Picture']) && file_exists($img_path)) { ?>
                        <img src="<?php echo $img_path; ?>">
                    <?php } else { ?>
                        <br><br><span style="color: gray;">No Image</span>
                    <?php } ?>
                </div>

                <div class="p-info">
                    <span class="p-cat"><?php echo $row['Category_Name']; ?></span>
                    <div class="p-name"><?php echo $row['Product_Name']; ?></div>
                    <div class="p-price">RM <?php echo number_format($row['Product_Price'], 2); ?></div>
                    <a href="product_details.php?id=<?php echo $row['Product_ID']; ?>" class="btn">View Details</a>
                </div>
            </div>
        <?php 
            } 
        } else { 
        ?>
            <div style="text-align: center; padding: 50px; color: gray; clear: both;">
                <h3>No products found.</h3>
                <p>Try searching for something else.</p>
                <a href="catalogue.php">View All Products</a>
            </div>
        <?php } ?>
        
        <div class="clear"></div>
    </div>
    
    <br><br>
</div>

<?php include_once 'includes/footer.php'; ?>

</body>
</html>

