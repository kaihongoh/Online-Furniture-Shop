<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'includes/config.php';
$user_id = $_SESSION['user_id'];

// Fetch user's orders
$sql = "SELECT 
    o.Order_ID, 
    o.Total_Amount, 
    o.Order_Status, 
    o.Order_Date,
    COUNT(oi.Product_ID) as Item_Count,  -- Changed from Item_ID to Product_ID
    GROUP_CONCAT(CONCAT(p.Product_Name, ' (x', oi.Quantity, ')') SEPARATOR ', ') as Items
FROM orders o
LEFT JOIN order_items oi ON o.Order_ID = oi.Order_ID
LEFT JOIN product p ON oi.Product_ID = p.Product_ID
WHERE o.User_ID = ?
GROUP BY o.Order_ID
ORDER BY o.Order_Date DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$orders = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Orders - Ikea4U</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/my_orders.css">
    <link rel="stylesheet" href="css/template.css">
</head>
<body class="bg-light">
    <?php include 'includes/header.php'; ?>  

    <div class="container py-5">
        <div class="row">
            <div class="col-12">
                <h2 class="fw-bold mb-4">My Orders</h2>
                
                <?php if(empty($orders)): ?>
                    <div class="card border-0 shadow-sm text-center py-5">
                        <div class="card-body">
                            <i class="bi bi-box-seam display-1 text-muted mb-4"></i>
                            <h4 class="text-muted mb-3">No orders yet</h4>
                            <p class="text-muted mb-4">You haven't placed any orders yet.</p>
                            <a href="product.php" class="btn btn-primary">Start Shopping</a>
                        </div>
                    </div>
                <?php else: ?>
                
                <div class="accordion" id="ordersAccordion">
                    <?php foreach($orders as $index => $order): 
                        $badgeClass = "warning";
                        if($order['Order_Status'] == 'Shipped') $badgeClass = "primary";
                        if($order['Order_Status'] == 'Completed') $badgeClass = "success";
                        if($order['Order_Status'] == 'Cancelled') $badgeClass = "danger";
                        
                        $orderDate = date("d M Y, h:i A", strtotime($order['Order_Date']));
                        $orderTotal = number_format($order['Total_Amount'], 2);
                    ?>
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-header bg-white" id="heading<?php echo $index; ?>">
                            <div class="d-flex justify-content-between align-items-center">
                                <button class="btn btn-link text-decoration-none text-dark fw-bold" 
                                        type="button" data-bs-toggle="collapse" 
                                        data-bs-target="#collapse<?php echo $index; ?>" 
                                        aria-expanded="true" aria-controls="collapse<?php echo $index; ?>">
                                    <i class="bi bi-chevron-down me-2"></i>
                                    Order #<?php echo $order['Order_ID']; ?>
                                </button>
                                
                                <div class="d-flex align-items-center gap-4">
                                    <span class="text-muted"><?php echo $orderDate; ?></span>
                                    <span class="badge bg-<?php echo $badgeClass; ?> bg-opacity-10 text-<?php echo $badgeClass; ?>">
                                        <?php echo $order['Order_Status']; ?>
                                    </span>
                                    <span class="fw-bold text-dark">RM <?php echo $orderTotal; ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div id="collapse<?php echo $index; ?>" class="collapse" 
                             aria-labelledby="heading<?php echo $index; ?>" data-bs-parent="#ordersAccordion">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h6 class="fw-bold mb-3">Order Details</h6>
                                        <p class="text-muted">Items: <?php echo $order['Items'] ?? 'N/A'; ?></p>
                                        <p class="text-muted">Total Items: <?php echo $order['Item_Count']; ?></p>
                                    </div>
                                    <div class="col-md-4 text-end">
                                        <h6 class="fw-bold mb-3">Order Summary</h6>
                                        <p class="mb-1">Subtotal: <span class="float-end">RM <?php echo $orderTotal; ?></span></p>
                                        <p class="mb-1">Shipping: <span class="float-end">RM 0.00</span></p>
                                        <hr class="my-2">
                                        <p class="fw-bold">Total: <span class="float-end">RM <?php echo $orderTotal; ?></span></p>
                                    </div>
                                </div>
                                
                                <div class="mt-3 pt-3 border-top">
                                    <div class="row">
                                        <div class="col-md-6">

                                        </div>
                                        <div class="col-md-6 text-end">
                                            <?php if($order['Order_Status'] == 'Shipped'): ?>
                                                <button class="btn btn-outline-success btn-sm">
                                                    <i class="bi bi-truck"></i> Track Order
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <?php endif; ?>
                
                <div class="mt-4">
                    <!-- CHANGED FROM Continue Shopping TO Go Back to Cart -->
                    <a href="cart.php" class="btn btn-outline-secondary">
                        <i class="bi bi-cart"></i> Go Back to Cart
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include 'includes/footer.php'; ?>
</body>
</html>