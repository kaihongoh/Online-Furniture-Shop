<?php
require_once 'includes/config.php';
session_start();

$errors =[];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // get data
    $product_name = trim($_POST['product_name']);
    $category_id = intval($_POST['category_id']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $description = trim($_POST['description']);

    //validatation
    if (empty($product_name)) {
        $errors[]="Product name is required";
    } else {
        // check the product name already exists
        $check_stmt = $conn->prepare("SELECT Product_ID FROM product WHERE Product_Name = ?");
        $check_stmt->bind_param("s", $product_name);
        $check_stmt->execute();
        $check_stmt->store_result();
        
        if ($check_stmt->num_rows > 0) {
            $errors[] = "Product name already exists. Please create the product with different name.";
        }
        $check_stmt->close();
    }
    
    if ($category_id <= 0) {
        $errors[]="Please select a category";
    }
    
    if ($price <= 0) {
        $errors[]="Please provide a valid price";
    }
    
    if ($stock < 0) {
        $errors[]="Stock quantity cannot be negative";
    }

    //upload image
$image_name = ""; //default blank

if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {

    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/avif'];
    $file_type = $_FILES['image']['type'];
    $file_size = $_FILES['image']['size'];

    if (!in_array($file_type, $allowed_types)) {//only accept
        $errors[] = "Only JPG, PNG, GIF and AVIF files are allowed";
    } elseif ($file_size > 2 * 1024 * 1024) {//limit 2mb
        $errors[] = "Image size must be less than 2MB";
    } else {
        $file_extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $image_name = uniqid() . '.' . $file_extension;
        $upload_path = 'uploads/products/' . $image_name;

        if (!file_exists('uploads/products')) {
            mkdir('uploads/products', 0777, true);
        }

        if (!move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
            $errors[] = "Failed to upload image";
            $image_name = "";
        }
    }
}


   // if no error, upload to database
    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO product (Product_Name, Category_ID, Product_Price, Product_Stock, Product_Description, Product_Picture, status) 
                               VALUES (?, ?, ?, ?, ?, ?, 'active')");
        $stmt->bind_param("sidiss", $product_name, $category_id, $price, $stock, $description, $image_name);
    
            //go back to product.php
            if ($stmt->execute()) {
                $_SESSION['message'] = 'success';   
                header("Location: product.php");
                exit();
        }else {
            $errors[] = "Failed to add product to database: " . $conn->error;
        }
        $stmt->close();
    }
}
//get category 
$categoryResult = $conn->query("SELECT * FROM category ORDER BY Category_Name");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product | Lakeshow Grocery</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/admin_sidebar.css">
    <link rel="stylesheet" href="css/AddProduct.css">
    
</head>
<body>
<?php include_once 'admin_sidebar.php'; ?>

    <div class="main-content">
        <div class="header">
            <h1>Add New Product</h1>
            <div class="header-right">
                <div class="user-info">
                    <img src="img/AdminLogo.webp" alt="Admin Profile">
                    <span></span>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="action-bar">
                <a href="product.php" class="btn btn-secondary btn-large" style="text-decoration: none;">
                     Back to Products
                </a>
            </div>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

            <form id="productForm" action="AddProduct.php" method="POST" enctype="multipart/form-data" class="product-form" novalidate>
                <div class="form-group">
                    <label for="product_name">Product Name </label>
                    <input type="text" id="product_name" name="product_name" class="form-control" 
                           value="<?php echo isset($_POST['product_name']) ? htmlspecialchars($_POST['product_name']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="category_id">Category </label>
                    <select id="category_id" name="category_id" class="form-control" required>
                        <option value="">Select Category</option>
                        <?php  // while loop
                    while ($row = $categoryResult->fetch_assoc()): 
                    ?>
                        <option value="<?php echo $row['Category_ID']; ?>"
                            <?php echo (isset($_POST['category_id']) && $_POST['category_id'] == $row['Category_ID']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($row['Category_Name']); ?>
                        </option>
                    <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="price">Price (RM) </label>
                    <input type="number" id="price" name="price" class="form-control" step="0.01" min="0.01" 
                           value="<?php echo isset($_POST['price']) ? htmlspecialchars($_POST['price']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="stock">Initial Stock Quantity </label>
                    <input type="number" id="stock" name="stock" class="form-control" min="0" 
                           value="<?php echo isset($_POST['stock']) ? htmlspecialchars($_POST['stock']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" class="form-control" rows="3">
                        <?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?>
                    </textarea>
                </div>

                <div class="form-group">
                    <label for="image">Product Image </label>
                    <input type="file" id="image" name="image" class="form-control" 
                           accept="image/jpeg,image/png,image/gif,image/webp,image/avif">
                    <small class="form-text">Maximum file size: 2MB. Allowed formats: JPG, PNG, GIF, AVIF. Leave empty to keep current image.</small>
                    
                    <div id="imagePreviewContainer" style="margin-top: 15px; display: none;">
                        <div><strong>Preview:</strong></div>
                        <img id="imagePreview" style="max-width: 250px; max-height: 250px; margin-top: 10px; border: 1px solid #ddd; border-radius: 6px; padding: 8px;">
                    </div>
                </div>
                
                <div class="form-group">
                    <button type="submit" id="submitBtn" class="btn btn-primary btn-large">
                         Save Product
                    </button>
                    <a href="product.php" class="btn btn-secondary btn-large">
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
<script>
        // preview image
        document.getElementById('image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            const previewContainer = document.getElementById('imagePreviewContainer');
            const previewImage = document.getElementById('imagePreview');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewImage.src = e.target.result;
                    previewContainer.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                previewContainer.style.display = 'none';
            }
        });

        // form validation
        document.getElementById('productForm').addEventListener('submit', function(e) {
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.innerHTML =  "Saving...";
            submitBtn.disabled = true;
        });
    </script>
</body>
</html>
