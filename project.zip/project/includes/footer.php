    <footer class="footer">
      <div class="footer-container">
        <div class="footer-about">
          <img
            src="image\Ikea4U-logo (1).png"
            alt="Lakeshow Grocer"
            class="footer-logo"
          />
          <p style="text-align:justify;">
            Some clubs are for the select few, 
            but IKEA Family is for everyone. 
            Become a Family member and enjoy rewards, discounts, 
            inspirations and a few surprises all year round.
          </p>
          <div class="footer-social">
            <a
              href="https://www.facebook.com"
              target="_blank"
              ><img src="image\fblogo.png" alt="facebook"
            /></a>
            <a href="https://www.instagram.com" target="_blank"
              ><img src="image\instalogo.png" alt="instagram"
            /></a>
            <a href="https://x.com" target="_blank"
              ><img src="image\X-Logo-Round-Color.png" alt="X"
            /></a>
          </div>
        </div>

        <div class="footer-links">
          <h3 class="footer-heading">Quick Links</h3>
          <ul class="footer-links">
            <li><a href="main page.php">Home</a></li>
            <li><a href="aboutUs.php">About Us</a></li>
            <li><a href="C_Order_History.php">Order History</a></li>
          </ul>
        </div>

        <div class="footer-links">
          <h3 class="footer-heading">Categories</h3>
          <ul class="footer-links">
            <li>
              <a href="get_products_by_category.php?category=1"
                >Armchairs</a
              >
            </li>
            <li>
              <a href="get_products_by_category.php?category=2"
                >Sofas</a
              >
            </li>
            <li>
              <a href="get_products_by_category.php?category=3">Storage Boxes & Baskets</a>
            </li>
            <li>
              <a href="get_products_by_category.php?category=4">Beds & Mattresses</a>
            </li>
            <li>
              <a href="get_products_by_category.php?category=5">Kitchen Kabinets</a>
            </li>
            <li>
              <a href="get_products_by_category.php?category=6"
                >Laundry & Cleaning</a
              >
            </li>
            <li>
              <a href="get_products_by_category.php?category=7">Home Decoration</a>
            </li>

          </ul>
        </div>

        <div class="footer-contact">
          <h3 class="footer-heading">Contact Us</h3>
          <p>
            Level 1, 2, Jalan PJU 7/2, Mutiara Damansara,
            47800 Petaling Jaya, Selangor
          </p>
          <p> 03-7952 7575</p>
          <p>customerservice.ikeamy@ikano.asia</p>
          <p>Mon-Sun: 9:30 am - 10:00 pm</p>
          <p style="text-align:justfy;">
            For IKEA Business inquiries, you can reach them at +603 7730 0194 or via email at business.ikeamy@ikano.asia. 
          </p>

          <h4 style="color: white; margin-top: 20px">We Accept</h4>
          <div class="payment-methods">
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2560px-Visa_Inc._logo.svg.png"
              alt="Visa"
              style="height: 30px; margin-right: 10px"
            />
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/1280px-Mastercard-logo.svg.png"
              alt="Mastercard"
              style="height: 30px"
            />
          </div>
        </div>
      </div>

      <div class="footer-copyright">
        <p>
          &copy; 2026 Ikea4U. All Rights Reserved. |
          <a
            href="#"
            >Privacy Policy</a
          >
          |
          <a
            href="#"
            >Terms of Service</a
          >
        </p>
      </div>
    </footer>