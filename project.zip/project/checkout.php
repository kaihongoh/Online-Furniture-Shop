<?php
session_start();
include 'includes/config.php';

// USER AUTHENTICATION
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// --- 1. HANDLE INCOMING ITEMS FROM CART ---
if (isset($_POST['proceed_checkout'])) {
    if (!empty($_POST['selected_items'])) {
        $_SESSION['checkout_items'] = $_POST['selected_items'];
    } else {
        header("Location: cart.php");
        exit();
    }
}

// Check if there are items to checkout
if (empty($_SESSION['checkout_items'])) {
    header("Location: cart.php");
    exit();
}

// --- 2. FETCH ITEM DETAILS FROM DATABASE ---
$total = 0;
$checkout_list = [];

// Use prepared statement to get cart items
$placeholders = implode(',', array_fill(0, count($_SESSION['checkout_items']), '?'));
$sql = "SELECT p.*, c.Quantity as cart_qty 
        FROM product p 
        JOIN cart c ON p.Product_ID = c.Product_ID 
        WHERE p.Product_ID IN ($placeholders) AND c.User_ID = ?";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $types = str_repeat('i', count($_SESSION['checkout_items'])) . 'i';
    $params = array_merge($_SESSION['checkout_items'], [$user_id]);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $pid = $row['Product_ID'];
        $qty = $row['cart_qty'];
        $price = $row['Product_Price'];
        $item_total = $price * $qty;
        $total += $item_total;
        
        $checkout_list[] = [
            'id' => $pid,
            'name' => $row['Product_Name'],
            'qty' => $qty,
            'price' => $price,
            'item_total' => $item_total
        ];
    }
    $stmt->close();
} else {
    die("Error preparing query: " . $conn->error);
}

// --- 3. FETCH USER ADDRESS & EMAIL ---
$saved_address = "";
$user_email = "";

$user_query = "SELECT Address, email FROM users WHERE User_ID = ?";
$user_stmt = $conn->prepare($user_query);
if ($user_stmt) {
    $user_stmt->bind_param("i", $user_id);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();
    
    if ($user_row = $user_result->fetch_assoc()) {
        $saved_address = trim($user_row['Address'] ?? '');
        if (!empty($user_row['email'])) {
            $user_email = $user_row['email'];
        }
    }
    $user_stmt->close();
}

// --- 4. HANDLE SUCCESSFUL PAYMENT ---
$success = false;
$new_order_id = null;

if (isset($_POST['pay_btn'])) {
    
    // Validate address is provided
    if (empty($saved_address)) {
        die("Error: Shipping address is required.");
    }
    
    // Validate payment form fields
    $card_name = trim($_POST['card_name'] ?? '');
    $card_number = trim($_POST['card_number'] ?? '');
    $card_expiry = trim($_POST['card_expiry'] ?? '');
    $card_cvv = trim($_POST['card_cvv'] ?? '');
    
    // Card validation
    $card_number_clean = preg_replace('/\D/', '', $card_number);
    if (strlen($card_number_clean) !== 16 || !is_numeric($card_number_clean)) {
        $error = "Card number must be exactly 16 digits.";
    }
    // Validate CVV: must be 3 digits
    elseif (strlen($card_cvv) !== 3 || !is_numeric($card_cvv)) {
        $error = "CVV must be exactly 3 digits.";
    }
    // Validate expiry date: must be MM/YY format
    elseif (!preg_match('/^(0[1-9]|1[0-2])\/([0-9]{2})$/', $card_expiry)) {
        $error = "Expiration date must be in MM/YY format (e.g., 12/25).";
    }
    // Check if all fields are filled
    elseif (empty($card_name) || empty($card_number) || empty($card_expiry) || empty($card_cvv)) {
        $error = "Please fill all payment fields.";
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Insert order
            $order_sql = "INSERT INTO orders (User_ID, Total_Amount, Order_Status, Order_Date) VALUES (?, ?, 'Pending', NOW())";
            $order_stmt = $conn->prepare($order_sql);
            $order_stmt->bind_param("id", $user_id, $total);
            
            if ($order_stmt->execute()) {
                $new_order_id = $conn->insert_id;
                $order_stmt->close();
                
                // Insert order items and update stock
                foreach ($checkout_list as $item) {
                    $pid = $item['id'];
                    $qty = $item['qty'];
                    $price = $item['price'];
                    
                    // Insert order item
                    $item_sql = "INSERT INTO order_items (Order_ID, Product_ID, Quantity, Price) VALUES (?, ?, ?, ?)";
                    $item_stmt = $conn->prepare($item_sql);
                    $item_stmt->bind_param("iiid", $new_order_id, $pid, $qty, $price);
                    $item_stmt->execute();
                    $item_stmt->close();
                    
                    // Update product stock
                    $stock_sql = "UPDATE product SET Product_Stock = Product_Stock - ? WHERE Product_ID = ?";
                    $stock_stmt = $conn->prepare($stock_sql);
                    $stock_stmt->bind_param("ii", $qty, $pid);
                    $stock_stmt->execute();
                    $stock_stmt->close();
                    
                    // Remove item from cart table
                    $remove_sql = "DELETE FROM cart WHERE User_ID = ? AND Product_ID = ?";
                    $remove_stmt = $conn->prepare($remove_sql);
                    $remove_stmt->bind_param("ii", $user_id, $pid);
                    $remove_stmt->execute();
                    $remove_stmt->close();
                }
                
                // Clear checkout items from session
                unset($_SESSION['checkout_items']);
                
                // Commit transaction
                $conn->commit();
                
                // Set success flag
                $success = true;
                
                // Send confirmation email
                $subject = "Payment Receipt - Order #$new_order_id";
                $message = "Your Order #$new_order_id has been placed successfully.\n\n";
                $message .= "Total Amount: RM " . number_format($total, 2) . "\n";
                $message .= "Shipping Address: $saved_address\n";
                $message .= "Order Status: Pending\n\n";
                $message .= "Thank you for your purchase!";
                
                $headers = "From: shop@ikea4u.com\r\n";
                $headers .= "Reply-To: shop@ikea4u.com\r\n";
                $headers .= "X-Mailer: PHP/" . phpversion();
                
                // Send email (uncomment when ready)
                // @mail($user_email, $subject, $message, $headers);
                
            } else {
                throw new Exception("Failed to create order: " . $order_stmt->error);
            }
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            die("Payment failed: " . $e->getMessage());
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Secure Checkout</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body class="bg-light">
<div class="container py-5">
    
    <?php if ($success): ?>
        <!-- SUCCESS MESSAGE -->
        <div class="card border-0 shadow text-center py-5 mx-auto" style="max-width: 500px;">
            <div class="card-body">
                <i class="bi bi-check-circle-fill text-success" style="font-size: 4rem;"></i>
                <h2 class="fw-bold mt-3">Payment Successful!</h2>
                <p class="text-muted">
                    Order #<?php echo $new_order_id; ?> placed successfully.<br>
                    Receipt sent to <?php echo htmlspecialchars($user_email); ?>
                </p>
                <div class="d-grid gap-2 col-8 mx-auto mt-4">
                    <a href="cart.php" class="btn btn-dark">Back to Products</a>
                </div>
            </div>
        </div>
    
    <?php else: ?>
        <!-- CHECKOUT PAGE -->

        <div class="mb-4">
            <button onclick="safeCancel()" class="btn btn-outline-danger">
                <i class="bi bi-arrow-left me-1"></i> Cancel & Return to Cart
            </button>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="row g-5">
            <!-- Right Column: Shipping & Order Summary -->
            <div class="col-md-5 order-md-last">
                
                <?php if (!empty($saved_address)): ?>
                <!-- Shipping Details Card -->
                <div class="card shadow-sm border-0 mb-3">
                    <div class="card-header bg-white fw-bold text-success">
                        <i class="bi bi-truck me-2"></i>Shipping Details
                    </div>
                    <div class="card-body">
                        <div class="d-flex align-items-start">
                            <i class="bi bi-geo-alt-fill text-success me-3 mt-1 fs-5"></i>
                            <div>
                                <h6 class="fw-bold mb-1">Ship To:</h6>
                                <p class="mb-1 text-muted"><?php echo htmlspecialchars($saved_address); ?></p>
                                <a href="cart.php" class="small text-decoration-none">Edit Address</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Order Summary Card -->
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold">Order Summary</div>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($checkout_list as $item): ?>
                        <li class="list-group-item d-flex justify-content-between lh-sm">
                            <div>
                                <h6 class="my-0"><?php echo htmlspecialchars($item['name']); ?></h6>
                                <small class="text-muted">x <?php echo $item['qty']; ?></small>
                            </div>
                            <span class="text-muted">RM <?php echo number_format($item['item_total'], 2); ?></span>
                        </li>
                        <?php endforeach; ?>
                        <!-- Total Amount -->
                        <li class="list-group-item d-flex justify-content-between bg-light fw-bold">
                            <span>Total Due</span>
                            <span class="text-primary">RM <?php echo number_format($total, 2); ?></span>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Left Column: Payment Details -->
            <div class="col-md-7">
                <div class="card shadow-sm border-0">
                    <div class="card-body p-4">
                        <h4 class="mb-4 fw-bold"><i class="bi bi-credit-card-2-front me-2"></i>Payment Details</h4>
                        
                        <?php if (empty($saved_address)): ?>
                            <!-- Address Required Warning -->
                            <div class="alert alert-danger text-center py-4">
                                <i class="bi bi-exclamation-triangle-fill fs-1 d-block mb-3"></i>
                                <h5 class="fw-bold">Shipping Address Required</h5>
                                <p class="mb-3">Please add an address before paying.</p>
                                <a href="cart.php" class="btn btn-danger fw-bold">Add Address</a>
                            </div>
                        <?php else: ?>
                            <!-- Payment Form -->
                            <form method="POST" id="paymentForm">
                                <!-- Card Name -->
                                <div class="mb-3">
                                    <label class="form-label">Name on Card</label>
                                    <input type="text" class="form-control" name="card_name" placeholder="Jack Lim" required>
                                </div>

                                <!-- Card Number -->
                                <div class="mb-3">
                                    <label class="form-label">Card Number</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white"><i class="bi bi-credit-card"></i></span>
                                        <input type="text" class="form-control" name="card_number" id="card_number" 
                                               placeholder="0000 0000 0000 0000" 
                                               maxlength="19" 
                                               pattern="\d{4}\s?\d{4}\s?\d{4}\s?\d{4}" 
                                               title="16-digit card number" 
                                               required>
                                    </div>
                                    <small class="form-text text-muted">Enter 16-digit card number (numbers only)</small>
                                </div>

                                <!-- Expiry and CVV -->
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Expiration Date</label>
                                        <input type="text" class="form-control" name="card_expiry" id="card_expiry" 
                                               placeholder="MM/YY" 
                                               maxlength="5" 
                                               pattern="(0[1-9]|1[0-2])\/([0-9]{2})" 
                                               title="MM/YY format (e.g., 12/25)" 
                                               required>
                                        <small class="form-text text-muted">Format: MM/YY (e.g., 12/25)</small>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">CVV / CVC</label>
                                        <div class="input-group">
                                            <input type="text" class="form-control" name="card_cvv" id="card_cvv" 
                                                   placeholder="123" 
                                                   maxlength="3" 
                                                   pattern="\d{3}" 
                                                   title="3-digit security code" 
                                                   required>
                                            <span class="input-group-text bg-white" title="3 digits on back"><i class="bi bi-question-circle"></i></span>
                                        </div>
                                        <small class="form-text text-muted">3-digit security code</small>
                                    </div>
                                </div>

                                <hr class="my-4">

                                <!-- Pay Button -->
                                <button class="btn btn-primary w-100 btn-lg fw-bold" type="submit" name="pay_btn" id="payBtn">
                                    Pay RM <?php echo number_format($total, 2); ?>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    <?php endif; ?>
</div>

<!-- Include external validation script -->
<script src="js/checkout-validation.js"></script>

<!-- Keep safeCancel function in main file -->
<script>
function safeCancel() {
    if (confirm("Cancel payment and return to cart?") == true) {
        window.location.href = "cart.php";
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>