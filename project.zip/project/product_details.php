<?php
session_start();
include 'includes/config.php';

if (isset($_GET['id'])) {
    $product_id = mysqli_real_escape_string($conn, $_GET['id']);
  
    $sql = "SELECT p.*, c.Category_Name 
            FROM product p 
            LEFT JOIN category c ON p.Category_ID = c.Category_ID 
            WHERE p.Product_ID = '$product_id' AND p.status = 'Active'";
    
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);
    } else {
        header("Location: catalogue.php?error=not_found");
        exit();
    }
} else {
    header("Location: catalogue.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['Product_Name']); ?> - Details</title> 
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/template.css">
    <style>
        /* 补充样式 - 只保留必要的 */
        .details-container {
            display: flex; 
            gap: 40px; 
            background: white;
            padding: 30px; 
            border-radius: 8px; 
            margin: 20px auto; 
            max-width: 1200px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .details-img { 
            flex: 1; 
            min-width: 400px;
        }
        .details-img img { 
            width: 100%; 
            max-width: 500px;
            border-radius: 8px; 
            object-fit: cover;
            border: 1px solid var(--border-color);
        }
        .details-info { 
            flex: 1; 
            padding: 20px;
        }
        .details-info h1 { 
            font-size: 2em; 
            margin-bottom: 10px; 
            color: var(--body-color);
        }
        .category-tag {
            display: inline-block;
            background: #f0f0f0;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 0.9em;
            color: var(--text-light);
            margin-bottom: 15px;
        }
        .details-price { 
            font-size: 1.8em; 
            color: #e67e22; 
            font-weight: bold; 
            margin: 20px 0; 
        }
        .stock-status { 
            padding: 5px 12px;
            background: #e7f7e7;
            color: var(--success-color);
            border-radius: 4px;
            display: inline-block;
            font-weight: bold; 
            margin-bottom: 20px;
        }
        .stock-status.low {
            background: #fff3cd;
            color: #856404;
        }
        .stock-status.out {
            background: #f8d7da;
            color: var(--error-color);
        }
        .product-description {
            line-height: 1.6;
            color: #555;
            margin: 20px 0;
            font-size: 1.1em;
        }
        .quantity-input { 
            width: 70px; 
            padding: 10px; 
            margin-right: 10px; 
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 16px;
        }
        .btn-add { 
            background-color: var(--primary-color); 
            color: white; 
            border: none; 
            padding: 12px 25px; 
            cursor: pointer; 
            border-radius: 5px; 
            font-size: 16px;
            transition: all 0.3s;
        }
        .btn-add:hover { 
            background-color: var(--primary-hover); 
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(42, 90, 60, 0.3);
        }
        .btn-login-prompt {
            background-color: var(--secondary-color); 
            color: white; 
            border: none; 
            padding: 12px 25px; 
            cursor: pointer; 
            border-radius: 5px; 
            font-size: 16px;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            transition: all 0.3s;
        }
        .btn-login-prompt:hover {
            background-color: #3a571e;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(42, 90, 60, 0.3);
        }
        .btn-back { 
            display: inline-block; 
            margin-top: 20px; 
            color: var(--text-light); 
            text-decoration: none;
            font-weight: bold;
        }
        .btn-back:hover {
            color: var(--primary-color);
        }
        .quantity-group {
            margin: 30px 0;
        }
        .quantity-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: var(--body-color);
        }
        .login-required {
            padding: 15px;
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            margin: 20px 0;
            border-radius: 4px;
        }
        .login-required p {
            margin: 0 0 10px 0;
            color: #856404;
        }
        .no-image-placeholder {
            background: var(--bg-color); 
            height: 400px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            border-radius: 8px; 
            color: var(--text-light);
        }
        .out-of-stock-box {
            padding: 15px; 
            background: #f8f9fa; 
            border-radius: 5px; 
            text-align: center;
        }
        .out-of-stock-box p {
            color: var(--text-light); 
            margin: 0;
        }
        .out-of-stock-box a {
            color: var(--primary-color); 
            font-weight: bold; 
            text-decoration: none;
        }
        .discount-price {
            color: #e74c3c; 
            font-size: 1.1em; 
            margin: 10px 0;
        }
        .discount-badge {
            background: #e74c3c; 
            color: white; 
            padding: 2px 8px; 
            border-radius: 3px; 
            font-size: 0.9em; 
            margin-left: 10px;
        }
        @media (max-width: 768px) {
            .details-container {
                flex-direction: column;
                gap: 20px;
                padding: 20px;
            }
            .details-img {
                min-width: 100%;
            }
        }
    </style>
</head>
<body>

<?php include_once 'includes/header.php'; ?>

<div class="container">
    <a href="catalogue.php" class="btn-back">← Back to Catalogue</a>
    
    <div class="details-container">
        <div class="details-img">
            <?php 
            $image_path = 'uploads/products/' . $product['Product_Picture'];
            $image_exists = (!empty($product['Product_Picture']) && file_exists($image_path));
            ?>
            <?php if($image_exists): ?>
                <img src="<?php echo $image_path; ?>" 
                     alt="<?php echo htmlspecialchars($product['Product_Name']); ?>"
                     onerror="this.onerror=null; this.src='uploads/products/default.jpg';">
            <?php else: ?>
                <div class="no-image-placeholder">
                    No Image Available
                </div>
            <?php endif; ?>
        </div>

        <div class="details-info">
            <h1><?php echo htmlspecialchars($product['Product_Name']); ?></h1>
            
            <span class="category-tag"><?php echo htmlspecialchars($product['Category_Name'] ?? 'Uncategorized'); ?></span>
            
            <?php 
            $stock = $product['Product_Stock'];
            $stock_class = 'stock-status';
            if ($stock < 10 && $stock > 0) {
                $stock_class .= ' low';
            } elseif ($stock <= 0) {
                $stock_class .= ' out';
            }
            ?>
            <div class="<?php echo $stock_class; ?>">
                <?php if ($stock > 0): ?>
                    In Stock: <?php echo $stock; ?> units
                <?php else: ?>
                    Out of Stock
                <?php endif; ?>
            </div>
            
            <div class="product-description">
                <?php 
                $description = $product['Product_Description'] ?? '';
                echo nl2br(htmlspecialchars($description));
                ?>
            </div>
            
            <hr style="margin: 30px 0; border: 0; border-top: 1px solid var(--border-color);">
            
            <div class="details-price">RM <?php echo number_format($product['Product_Price'], 2); ?></div>

            <?php if ($product['Dis_Price'] && $product['Dis_Price'] < $product['Product_Price']): ?>
                <div class="discount-price">
                    <s>RM <?php echo number_format($product['Product_Price'], 2); ?></s>
                    <strong> RM <?php echo number_format($product['Dis_Price'], 2); ?></strong>
                    <span class="discount-badge">
                        SAVE <?php echo round(100 - ($product['Dis_Price'] / $product['Product_Price'] * 100)); ?>%
                    </span>
                </div>
            <?php endif; ?>

            <?php if ($stock > 0): ?>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <!-- User is logged in - show normal add to cart form -->
                    <form action="cart_action.php" method="POST" onsubmit="return validateQuantity(event)">
                        <input type="hidden" name="product_id" value="<?php echo $product['Product_ID']; ?>">
                        
                        <div class="quantity-group">
                            <label for="quantity">Quantity:</label>
                            <input type="number" id="quantity" name="quantity" class="quantity-input" 
                                   value="1" min="1" max="<?php echo $stock; ?>">
                            <button type="submit" name="add_to_cart" class="btn-add">Add to Cart</button>
                        </div>
                    </form>
                <?php else: ?>
                    <!-- User is NOT logged in - show login prompt -->
                    <div class="login-required">
                        <p>You need to log in or register to add items to your shopping cart.</p>
                        <div class="quantity-group">
                            <label for="quantity">Quantity:</label>
                            <input type="number" id="quantity" class="quantity-input" 
                                   value="1" min="1" max="<?php echo $stock; ?>" readonly>
                            <button type="button" class="btn-login-prompt" onclick="promptLogin()">Login to Add to Cart</button>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="out-of-stock-box">
                    <p>This product is currently out of stock.</p>
                    <a href="catalogue.php">Browse Other Products →</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    function validateQuantity(event) {
        var qtyInput = document.getElementById("quantity");
        var qty = parseInt(qtyInput.value);
        var maxStock = <?php echo $stock; ?>;

        if (isNaN(qty) || qty <= 0) {
            alert("❌ Error: Please enter a valid quantity (at least 1).");
            event.preventDefault(); 
            return false;
        }

        if (qty > maxStock) {
            alert("❌ Stock Limit: We only have " + maxStock + " units available.");
            event.preventDefault();
            return false;
        }
        return true; 
    }

    function promptLogin() {
        if (confirm("You need to log in or register to add items to your shopping cart.\n\nWould you like to go to the login page?")) {
            window.location.href = "login.php";
        }
    }

    // check url
    document.addEventListener('DOMContentLoaded', function() {
        const urlParams = new URLSearchParams(window.location.search);
        
        // alert success
        if (urlParams.has('success')) {
            if (urlParams.get('success') === 'added') {
                alert('✅ Product added to cart successfully!');
            } else if (urlParams.get('success') === 'updated') {
                alert('✅ Cart quantity updated successfully!');
            }
            // 清除URL参数
            removeUrlParam('success');
        }
        
        // alert error
        if (urlParams.has('error')) {
            if (urlParams.get('error') === 'insufficient_stock') {
                alert('❌ Insufficient stock! The quantity requested exceeds available stock.');
            } else if (urlParams.get('error') === 'not_found') {
                alert('❌ Product not found or is no longer available!');
            } else if (urlParams.get('error') === 'invalid_quantity') {
                alert('❌ Please enter a valid quantity (at least 1).');
            } else if (urlParams.get('error') === 'server_error') {
                alert('❌ An error occurred while adding to cart. Please try again.');
            } else if (urlParams.get('error') === 'login_required') {
                alert('🔒 Please log in to add items to your shopping cart.');
            }
            removeUrlParam('error');
        }
        
        // clear success param
        if (urlParams.has('success')) {
            removeUrlParam('success');
        }
    });
    
    // remove url param
    function removeUrlParam(paramName) {
        const url = new URL(window.location);
        url.searchParams.delete(paramName);
        // keep id
        if (url.searchParams.has('id')) {
            const id = url.searchParams.get('id');
            url.searchParams.delete('id');
            window.history.replaceState({}, '', url.pathname + '?id=' + id);
        } else {
            window.history.replaceState({}, '', url);
        }
    }
</script>

<?php include_once 'includes/footer.php'; ?>
</body>
</html>