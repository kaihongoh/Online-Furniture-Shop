<?php
require_once 'includes/config.php';
session_start(); //start session to store temporary messages
// acive and inactive product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']); // get product id safely as integer
    
    // check is active or inactive, check if admin wants to deactivate a product
    if (isset($_POST['inactive_product'])) {
        // update product status to inactive 
        $stmt = $conn->prepare("UPDATE product SET status = 'inactive' WHERE Product_ID = ?");
        $stmt->bind_param("i", $product_id);
        if ($stmt->execute()) { //store success message in session
            $_SESSION['message'] = 'deactivated';
        } else { //store error message in session
            $_SESSION['message'] = 'error';
        }
        $stmt->close();
    } elseif (isset($_POST['active_product'])) {
        //update product status to active
        $stmt = $conn->prepare("UPDATE product SET status = 'active' WHERE Product_ID = ?");
        $stmt->bind_param("i", $product_id);
        if ($stmt->execute()) {
            $_SESSION['message'] = 'activated';
        } else {
            $_SESSION['message'] = 'error';
        }
        $stmt->close();
    }
    
    //go back to same page while keeping search filter
    $query_params = [];
    if (isset($_GET['productname']) && !empty($_GET['productname'])) {
        $query_params['productname'] = $_GET['productname'];
    }
    if (isset($_GET['category']) && !empty($_GET['category'])) {
        $query_params['category'] = $_GET['category'];
    }
    if (isset($_GET['stock']) && !empty($_GET['stock'])) {
        $query_params['stock'] = $_GET['stock'];
    }
    
    $redirect_url = "product.php";
    if (!empty($query_params)) {
        $redirect_url .= "?" . http_build_query($query_params);
    }
    
    header("Location: $redirect_url");
    exit();
}

// retrieve and clear session message (if exists)
$message=null;
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']);
}

//count total active product items
$countproductsql = "SELECT COUNT(*) FROM product WHERE status = 'active'";
$stmtcount = $conn->prepare($countproductsql);
$stmtcount->execute();
$stmtcount->bind_result($totalActiveProducts);
$stmtcount->fetch();
$stmtcount->close();

//count total inactive product items
$countinactiveproductsql = "SELECT COUNT(*) FROM product WHERE status != 'active'";
$stmtcount = $conn->prepare($countinactiveproductsql);
$stmtcount->execute();
$stmtcount->bind_result($totalInactiveProducts);
$stmtcount->fetch();
$stmtcount->close();

//count low stock products (stock < 10)
$lowstocksql = "SELECT COUNT(*) FROM product WHERE Product_Stock < 10 AND status = 'active'";
$stmtlow = $conn->prepare($lowstocksql);
$stmtlow->execute();
$stmtlow->bind_result($lowStockProducts);
$stmtlow->fetch();
$stmtlow->close();

//filter condition
$filter = "";
if (isset($_GET['stock']) && !empty($_GET['stock'])) {
    if ($_GET['stock'] == 'low') {
        $filter .= " AND product.Product_Stock < 10";
    } elseif ($_GET['stock'] == 'out') {
        $filter .= " AND product.Product_Stock = 0";
    } elseif ($_GET['stock'] == 'in') {
        $filter .= " AND product.Product_Stock >= 10";
    }
}
//filter by product name
if (isset($_GET['productname']) && !empty($_GET['productname'])) {
    $filter .= " AND product.Product_Name LIKE '%".$_GET['productname']."%'";
}
//filter by category
if (isset($_GET['category']) && !empty($_GET['category'])) {
    $filter .= " AND category.Category_Name = '".$_GET['category']."'";
}
//retrieve product list with category information
$productsQuery = "SELECT product.*, category.Category_Name FROM product INNER JOIN category 
                    ON product.Category_ID = category.Category_ID 
                    WHERE 1" . $filter;

$productsQuery .= " ORDER BY product.Product_ID";

$productsResult = $conn->query($productsQuery);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management - Ikea4U</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/admin_sidebar.css">
    <link rel="stylesheet" href="css/product.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    
</head>

<body>
   <?php include 'admin_sidebar.php'; ?>
    <div class="main-content">
        <div class="header">
            <h1>Product Management</h1>
            <div class="header-right">
                <div class="user-info">
                </div>
            </div>
        </div>
    

        <div class="content">
                    
<?php if (!empty($message)): ?>

    <div class="alert alert-<?php echo ($message == 'error') ? 'error' : 'success'; ?>" id="successAlert">
       <?php 
       if ($message == "activated"): 
            echo "The product status has been activated"; 
        elseif ($message == "deactivated"):  
            echo "The product status has been deactivated"; 
		elseif ($message == "success"):  
             echo "The product has been added successfully"; 
        elseif ($message == "error"): 
             echo "There was an error updating the product status."; 
        endif;
        ?>
        </div>

<?php endif; ?>


            <h2 class="page-title">Product Overview</h2>

            <div class="cards">
                <div class="card"> <!--product overview of total active product-->
                    <div class="card-header">
                        <span class="card-title">Total Active Products</span>
                    </div>
                    <div class="card-value"><?php echo $totalActiveProducts; ?></div>
                    <div class="card-footer">All active products</div>
                </div>
                <div class="card">
                    <div class="card-header"><!--product overview of total inactive product-->
                        <span class="card-title">Total Inactive Products</span>
                    </div>
                    <div class="card-value"><?php echo $totalInactiveProducts; ?></div>
                    <div class="card-footer">All inactive products</div>
                </div>
                <div class="card">
                    <div class="card-header"><!--product overview of low stock product-->
                        <span class="card-title">Low Stock</span>
                    </div>
                    <div class="card-value"><?php echo $lowStockProducts; ?></div>
                    <div class="card-footer">Products with stock < 10</div>
                </div>
            </div>
<form action="" method="GET" class="filter-form">
            <div class="search-filters">
                <div class="filter-group">
                    <label for="productSearch">Search Products</label>
                    <input type="text" id="productSearch" 
                    placeholder="Name or ID..." class="search-input" 
                    name="productname" 
                    value="<?php echo isset($_GET['productname']) ? htmlspecialchars($_GET['productname']) : ''; ?>">
                </div>

                <div class="filter-group">
                    <label for="categoryFilter">Category</label>
                    <select id="categoryFilter" class="form-control" name="category">
                        <option value="">All Categories</option>
                        <?php 
                        
                        $categoriesQuery = "SELECT * FROM category ORDER BY Category_Name";
                        $categoriesResult = $conn->query($categoriesQuery);

                    while ($category = $categoriesResult->fetch_assoc()): ?>
                            <option value="<?php echo htmlspecialchars($category['Category_Name']); ?>">
                                <?php echo htmlspecialchars($category['Category_Name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="stockFilter">Stock Status</label>
                    <select id="stockFilter" class="form-control" name="stock">
                        <option value="">All</option>
                        <option value="low" <?php echo (isset($_GET['stock']) && $_GET['stock'] == 'low') ? 'selected' : ''; ?>>Low Stock (low than 10) </option>
                         <option value="out" <?php echo (isset($_GET['stock']) && $_GET['stock'] == 'out') ? 'selected' : ''; ?>>Out of Stock </option>
                        <option value="in" <?php echo (isset($_GET['stock']) && $_GET['stock'] == 'in') ? 'selected' : ''; ?>>In Stock </option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-search">Search
                </button>
            </div>
            </form>

            <div class="action-bar">
                <a href="AddProduct.php" class="btn btn-primary btn-large"> Add Product
                </a>
            </div>
            
             <!-- product grid display-->
            <div class="product-grid">
                <?php if ($productsResult->num_rows > 0): ?>
                    <?php while($product = $productsResult->fetch_assoc()): ?>
                        <div class="product-card">
                            <div class="product-image">
                                <?php if (!empty($product['Product_Picture'])): ?>
                                    <img src="uploads/products/<?php echo htmlspecialchars($product['Product_Picture']); ?>" 
                                         alt="<?php echo htmlspecialchars($product['Product_Name']); ?>">
                                    <?php else: ?>
                                    <div class="no-image">
                                        <span>No Image</span>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="product-info">
                                <h4 title="<?php echo htmlspecialchars($product['Product_Name']); ?>">
                                    <?php echo htmlspecialchars($product['Product_Name']); ?>
                                </h4>
                                <p class="category">
                                <?php echo htmlspecialchars($product['Category_Name']); ?>
                                </p>
                                <p class="price">RM <?php echo number_format($product['Product_Price'], 2); ?></p>
                                <p class="stock">Stock: 
                                    <?php echo $product['Product_Stock']; ?>
                                   
                                </p>
                            </div>
                               
                                <div class="product-actions">
                                        <!-- edit button -->
                                        <a href="EditProduct.php?id=<?php echo $product['Product_ID']; ?>" 
                                        class="btn btn-edit">Edit
                                        </a>
                                        <!--active button change-->
                                <?php if (strtolower($product['status']) === 'active'): ?>
                                    <form method="POST" action="product.php">
                                        <input type="hidden" name="product_id" value="<?php echo $product['Product_ID']; ?>">
                                        <input type="hidden" name="inactive_product" value="Inactive">
                                        <button type="submit" class="btn btn-delete" 
                                                onclick="return confirm('Are you sure you want to mark this product as inactive? This will hide it from customers.');">
                                                Make Inactive
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <form method="POST" action="product.php">
                                        <input type="hidden" name="product_id" value="<?php echo $product['Product_ID']; ?>">
                                        <input type="hidden" name="active_product" value="Active"> 
                                        <button type="submit" class="btn btn-primary" 
                                                onclick="return confirm('Are you sure you want to activate this product? It will be visible to customers.');">
                                                Make Active
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="no-products-found">
                        <h3>No products found</h3>
                        <p>Try adjusting your search filters or add a new product.</p>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<script>
    // Auto-hide success message after 5 seconds
    const successAlert = document.getElementById('successAlert');
    if (successAlert) {
        setTimeout(() => {
            successAlert.style.opacity = '0';
            successAlert.style.transition = 'opacity 0.5s';
            setTimeout(() => {
                successAlert.style.display = 'none';
            }, 500);
        }, 5000);
    }
</script>
</body>
</html>
