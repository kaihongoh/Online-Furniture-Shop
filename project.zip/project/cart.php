<?php
session_start();
include 'includes/config.php';

// USER AUTHENTICATION
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$uid = $_SESSION['user_id']; 
$msg = ""; 

// CART OPERATIONS
if (isset($_GET['remove'])) {
    $stmt = $conn->prepare("DELETE FROM cart WHERE User_ID = ? AND Product_ID = ?");
    $stmt->bind_param("ii", $uid, $_GET['remove']);
    $stmt->execute();
    header("Location: cart.php"); 
    exit();
}

if (isset($_GET['op'], $_GET['pid'])) {
    $pid = $_GET['pid'];
    $op = $_GET['op'];
    
    // Get current quantity
    $stmt = $conn->prepare("SELECT Quantity FROM cart WHERE User_ID = ? AND Product_ID = ?");
    $stmt->bind_param("ii", $uid, $pid);
    $stmt->execute();
    $result = $stmt->get_result();
    $currentQty = $result->fetch_assoc()['Quantity'] ?? 0;
    
    // Get product stock
    $stockResult = $conn->query("SELECT Product_Stock FROM product WHERE Product_ID = $pid");
    $stock = $stockResult->fetch_assoc()['Product_Stock'] ?? 0;
    
    if ($op == 'inc' && $currentQty < $stock) {
        $newQty = $currentQty + 1;
        $stmt = $conn->prepare("UPDATE cart SET Quantity = ? WHERE User_ID = ? AND Product_ID = ?");
        $stmt->bind_param("iii", $newQty, $uid, $pid);
        $stmt->execute();
    } elseif ($op == 'dec' && $currentQty > 1) {
        $newQty = $currentQty - 1;
        $stmt = $conn->prepare("UPDATE cart SET Quantity = ? WHERE User_ID = ? AND Product_ID = ?");
        $stmt->bind_param("iii", $newQty, $uid, $pid);
        $stmt->execute();
    } elseif ($currentQty >= $stock) {
        $msg = "<div class='alert alert-warning'>Only $stock items left in stock!</div>";
    }
    
    if (empty($msg)) { 
        header("Location: cart.php"); 
        exit(); 
    }
}

// SAVE/UPDATE SHIPPING ADDRESS
if (isset($_POST['save_address'])) {
    $addr = trim($_POST['address']);
    $post = preg_replace('/\D/', '', $_POST['postcode']);
    $state = trim($_POST['state']);
    
    if ($addr && strlen($post) == 5 && $state) {
        $stmt = $conn->prepare("UPDATE users SET Address = ?, Postcode = ?, State = ? WHERE User_ID = ?");
        $stmt->bind_param("sssi", $addr, $post, $state, $uid);
        
        if ($stmt->execute()) {
            $msg = "<div class='alert alert-success'>Shipping details updated!</div>";
        }
        $stmt->close();
    } else {
        $msg = "<div class='alert alert-danger'>All address fields are required.</div>";
    }
}

// FETCH USER AND CART DATA
$user = $conn->query("SELECT Address, Postcode, State FROM users WHERE User_ID = $uid")->fetch_assoc();
$db_address  = $user['Address'] ?? '';
$db_postcode = $user['Postcode'] ?? '';
$db_state    = $user['State'] ?? '';

// Get cart items from database
$cart_items = [];
$stmt = $conn->prepare("
    SELECT c.*, p.Product_Name, p.Product_Price, p.Product_Stock 
    FROM cart c 
    JOIN product p ON c.Product_ID = p.Product_ID 
    WHERE c.User_ID = ?
");
$stmt->bind_param("i", $uid);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $stock = $row['Product_Stock'];
    $qty = min($row['Quantity'], $stock);
    
    // Update if quantity exceeds stock
    if ($row['Quantity'] != $qty) {
        $updateStmt = $conn->prepare("UPDATE cart SET Quantity = ? WHERE User_ID = ? AND Product_ID = ?");
        $updateStmt->bind_param("iii", $qty, $uid, $row['Product_ID']);
        $updateStmt->execute();
        $updateStmt->close();
    }
    
    $cart_items[] = [
        'id' => $row['Product_ID'],
        'name' => $row['Product_Name'],
        'price' => $row['Product_Price'],
        'qty' => $qty,
        'subtotal' => $row['Product_Price'] * $qty,
        'stock' => $stock,
        'badge' => $stock > 0 ? "In Stock" : "Out of Stock",
        'color' => $stock > 0 ? "success" : "danger"
    ];
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shopping Cart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/cart.css">
    <link rel="stylesheet" href="css/template.css">
</head>
<body class="bg-light">
    <?php include_once 'includes/header.php'; ?>

    <div class="container cart-container py-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold mb-0">Your Shopping Cart</h2>
            <a href="my_orders.php" class="btn btn-outline-secondary">
                <i class="bi bi-clock-history"></i> View Order History
            </a>
        </div>
        
        <?php echo $msg; ?>

        <div class="row g-4">
            <div class="col-lg-8">
                <?php if(empty($cart_items)): ?>
                    <div class="cart-card">
                        <div class="cart-header">Items List</div>
                        <div class="alert alert-secondary text-center py-5 rounded-0 mb-0">
                            <h1 class="display-1 text-muted"><i class="bi bi-cart-x"></i></h1>
                            <h4 class="mt-3">Your cart is currently empty.</h4>
                            <a href="home.php" class="btn btn-dark mt-3 me-2">Start Shopping</a>
                            <a href="my_orders.php" class="btn btn-outline-dark mt-3">View My Orders</a>
                        </div>
                    </div>
                <?php else: ?>
                    <form action="checkout.php" method="POST" id="checkoutForm">
                        <div class="cart-card">
                            <div class="cart-header">Items List</div>
                            <table class="table table-cart mb-0">
                                <thead>
                                    <tr>
                                        <th width="40"><input type="checkbox" checked onclick="toggleAll(this)"></th>
                                        <th>Product</th>
                                        <th>Status</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Total</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($cart_items as $item): ?>
                                    <tr>
                                        <td><input type="checkbox" name="selected_items[]" value="<?php echo $item['id']; ?>" checked class="item-check"></td>
                                        <td><div class="product-name"><?php echo $item['name']; ?></div></td>
                                        <td>
                                            <span class="badge rounded-pill bg-<?php echo $item['color']; ?> bg-opacity-10 text-<?php echo $item['color']; ?>">
                                                <?php echo $item['badge']; ?>
                                            </span>
                                        </td>
                                        <td>RM <?php echo number_format($item['price'], 2); ?></td>
                                        <td>
                                            <div class="qty-group">
                                                <a href="cart.php?op=dec&pid=<?php echo $item['id']; ?>" class="qty-btn text-decoration-none">
                                                    <i class="bi bi-dash"></i>
                                                </a>
                                                <input type="text" class="qty-input" value="<?php echo $item['qty']; ?>" readonly>
                                                <a href="cart.php?op=inc&pid=<?php echo $item['id']; ?>" class="qty-btn text-decoration-none">
                                                    <i class="bi bi-plus"></i>
                                                </a>
                                            </div>
                                        </td>
                                        <td class="fw-bold">RM <?php echo number_format($item['subtotal'], 2); ?></td>
                                        <td>
                                            <a href="cart.php?remove=<?php echo $item['id']; ?>" class="text-danger" title="Remove Item">
                                                <i class="bi bi-trash3-fill"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                <?php endif; ?>
            </div>

            <div class="col-lg-4">
                <div class="address-card">
                    <div class="address-title"><i class="bi bi-truck me-2"></i> Shipping Details</div>
                    
                    <form method="POST" id="addressForm">
                        <div class="mb-3">
                            <label class="form-label-sm">Street Address</label>
                            <textarea name="address" class="form-control custom-input" rows="2" 
                                      placeholder="Unit, Building, Street..." required><?php echo htmlspecialchars($db_address); ?></textarea>
                        </div>

                        <div class="row g-2 mb-3">
                            <div class="col-6">
                                <label class="form-label-sm">Postcode</label>
                                <input type="text" name="postcode" class="form-control custom-input" 
                                       value="<?php echo htmlspecialchars($db_postcode); ?>" 
                                       placeholder="e.g. 75450" 
                                       maxlength="5" 
                                       oninput="this.value = this.value.replace(/\D/g, '')" 
                                       required>
                            </div>
                            <div class="col-6">
                                <label class="form-label-sm">State</label>
                                <select name="state" class="form-select custom-input" required>
                                    <option value="">Select...</option>
                                    <?php 
                                    $states = ["Johor", "Kedah", "Kelantan", "Melaka", "Negeri Sembilan", 
                                               "Pahang", "Perak", "Perlis", "Penang", "Sabah", "Sarawak", 
                                               "Selangor", "Terengganu", "KL", "Putrajaya"];
                                    foreach($states as $st) {
                                        $selected = ($db_state == $st) ? 'selected' : '';
                                        echo "<option value='$st' $selected>$st</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>

                        <button name="save_address" class="btn btn-outline-primary w-100 fw-bold mb-4">
                            <i class="bi bi-arrow-repeat"></i> Update Shipping Details
                        </button>
                    </form>
                    
                    <hr class="text-muted">

                    <?php if(!empty($cart_items)): ?>
                        <button type="submit" form="checkoutForm" name="proceed_checkout" class="btn btn-checkout w-100 py-3 mt-2">
                            PROCEED TO CHECKOUT <i class="bi bi-arrow-right ms-2"></i>
                        </button>
                    <?php else: ?>
                        <button type="button" class="btn btn-checkout w-100 py-3 mt-2" style="opacity: 0.7;" onclick="showEmptyCartAlert()">
                            PROCEED TO CHECKOUT <i class="bi bi-arrow-right ms-2"></i>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
    function toggleAll(source) {
        document.querySelectorAll('.item-check').forEach(checkbox => {
            checkbox.checked = source.checked;
        });
    }

    document.getElementById('addressForm')?.addEventListener('submit', function(e) {
        const postcodeInput = this.querySelector('input[name="postcode"]');
        if (postcodeInput && postcodeInput.value.length !== 5) {
            e.preventDefault();
            alert('Postcode must be exactly 5 digits.');
            postcodeInput.focus();
            return false;
        }
        return true;
    });

    document.getElementById('checkoutForm')?.addEventListener('submit', function(e) {
        if (document.querySelectorAll('.item-check:checked').length === 0) {
            e.preventDefault();
            alert('Please select at least one item to checkout.');
            return false;
        }
        return true;
    });

    function showEmptyCartAlert() {
        alert('There are no items in your cart to checkout.\n\nPlease add items to your cart first.');
    }
    </script>
    
    <?php include_once 'includes/footer.php'; ?>
</body>
</html>