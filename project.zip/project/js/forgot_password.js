    //real time get security question
    document.getElementById('email').addEventListener('input', function() {
        const email = this.value.trim();
        const questionInput = document.getElementById('security_question');
        
        if (email.length > 0 && email.includes('@')) {
            //show loading state
            questionInput.placeholder = "Loading security question...";
            
            // use fetch API to get security question
            fetch('get_security_question.php?email=' + encodeURIComponent(email))
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.text();
                })
                .then(data => {
                    if (data) {
                        questionInput.value = data;
                        questionInput.placeholder = "";
                    } else {
                        questionInput.value = "";
                        questionInput.placeholder = "No security question found for this email";
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    questionInput.value = "";
                    questionInput.placeholder = "Error loading security question";
                });
        } else {
            questionInput.value = "";
            questionInput.placeholder = "Enter email above to see security question";
        }
    });