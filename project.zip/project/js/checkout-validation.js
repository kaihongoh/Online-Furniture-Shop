// checkout-validation.js
// Payment form validation and formatting

// Global function for cancel button (kept in main file since it's navigation)
function safeCancel() {
    if (confirm("Cancel payment and return to cart?") == true) {
        window.location.href = "cart.php";
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap alerts
    var alertList = document.querySelectorAll('.alert');
    alertList.forEach(function(alert) {
        new bootstrap.Alert(alert);
    });
    
    // Set up payment form validation if form exists
    const paymentForm = document.getElementById('paymentForm');
    if (paymentForm) {
        setupPaymentFormValidation();
    }
});

// Main function to set up payment form validation
function setupPaymentFormValidation() {
    const cardNumberInput = document.getElementById('card_number');
    const cardExpiryInput = document.getElementById('card_expiry');
    const cardCvvInput = document.getElementById('card_cvv');
    const paymentForm = document.getElementById('paymentForm');
    
    if (!cardNumberInput || !cardExpiryInput || !cardCvvInput || !paymentForm) {
        return; // Exit if elements don't exist
    }
    
    // Format card number with spaces as user types
    cardNumberInput.addEventListener('input', function(e) {
        formatCardNumber(e.target);
    });
    
    // Format expiry date as user types
    cardExpiryInput.addEventListener('input', function(e) {
        formatExpiryDate(e.target);
    });
    
    // Restrict CVV to 3 digits only
    cardCvvInput.addEventListener('input', function(e) {
        restrictCvvInput(e.target);
    });
    
    // Validate form before submission
    paymentForm.addEventListener('submit', function(e) {
        if (!validatePaymentForm()) {
            e.preventDefault();
            return false;
        }
        return true;
    });
    
    // Real-time validation as user types
    cardNumberInput.addEventListener('blur', validateCardNumber);
    cardExpiryInput.addEventListener('blur', validateExpiryDate);
    cardCvvInput.addEventListener('blur', validateCvv);
}

// Format card number: 0000 0000 0000 0000
function formatCardNumber(input) {
    let value = input.value.replace(/\D/g, '');
    let formatted = '';
    
    for (let i = 0; i < value.length && i < 16; i++) {
        if (i > 0 && i % 4 === 0) formatted += ' ';
        formatted += value[i];
    }
    
    input.value = formatted;
    validateCardNumber();
}

// Format expiry date: MM/YY
function formatExpiryDate(input) {
    let value = input.value.replace(/\D/g, '');
    
    if (value.length >= 2) {
        input.value = value.substring(0, 2) + '/' + value.substring(2, 4);
    } else {
        input.value = value;
    }
    validateExpiryDate();
}

// Restrict CVV to 3 digits
function restrictCvvInput(input) {
    input.value = input.value.replace(/\D/g, '').substring(0, 3);
    validateCvv();
}

// Validate card number
function validateCardNumber() {
    const input = document.getElementById('card_number');
    const value = input.value.replace(/\D/g, '');
    const isValid = value.length === 16 && /^\d+$/.test(value);
    
    updateValidationState(input, isValid, 'Card number must be exactly 16 digits.');
    return isValid;
}

// Validate expiry date
function validateExpiryDate() {
    const input = document.getElementById('card_expiry');
    const value = input.value;
    const expiryRegex = /^(0[1-9]|1[0-2])\/([0-9]{2})$/;
    let isValid = expiryRegex.test(value);
    let errorMessage = 'Expiration date must be in MM/YY format (e.g., 12/25).';
    
    if (isValid) {
        const [month, year] = value.split('/');
        const currentYear = new Date().getFullYear() % 100;
        const currentMonth = new Date().getMonth() + 1;
        
        if (parseInt(year) < currentYear || 
            (parseInt(year) === currentYear && parseInt(month) < currentMonth)) {
            isValid = false;
            errorMessage = 'Card has expired. Please use a valid expiration date.';
        }
    }
    
    updateValidationState(input, isValid, errorMessage);
    return isValid;
}

// Validate CVV
function validateCvv() {
    const input = document.getElementById('card_cvv');
    const value = input.value;
    const isValid = value.length === 3 && /^\d+$/.test(value);
    
    updateValidationState(input, isValid, 'CVV must be exactly 3 digits.');
    return isValid;
}

// Update input validation state
function updateValidationState(input, isValid, errorMessage) {
    if (isValid) {
        input.classList.remove('is-invalid');
        input.classList.add('is-valid');
        // Remove any existing error message
        const errorElement = input.nextElementSibling;
        if (errorElement && errorElement.classList.contains('invalid-feedback')) {
            errorElement.remove();
        }
    } else {
        input.classList.remove('is-valid');
        input.classList.add('is-invalid');
        // Add or update error message
        let errorElement = input.nextElementSibling;
        if (!errorElement || !errorElement.classList.contains('invalid-feedback')) {
            errorElement = document.createElement('div');
            errorElement.className = 'invalid-feedback';
            input.parentNode.insertBefore(errorElement, input.nextSibling);
        }
        errorElement.textContent = errorMessage;
    }
}

// Main validation function for form submission
function validatePaymentForm() {
    const cardNumberValid = validateCardNumber();
    const expiryValid = validateExpiryDate();
    const cvvValid = validateCvv();
    
    if (!cardNumberValid || !expiryValid || !cvvValid) {
        // Focus on first invalid field
        if (!cardNumberValid) document.getElementById('card_number').focus();
        else if (!expiryValid) document.getElementById('card_expiry').focus();
        else if (!cvvValid) document.getElementById('card_cvv').focus();
        
        // Show alert with all errors
        let errors = [];
        if (!cardNumberValid) errors.push('• Card number must be exactly 16 digits');
        if (!expiryValid) {
            const expiryInput = document.getElementById('card_expiry');
            const expiryError = expiryInput.nextElementSibling;
            errors.push('• ' + (expiryError ? expiryError.textContent : 'Invalid expiration date'));
        }
        if (!cvvValid) errors.push('• CVV must be exactly 3 digits');
        
        alert('Please fix the following errors:\n\n' + errors.join('\n'));
        return false;
    }
    
    return true;
}