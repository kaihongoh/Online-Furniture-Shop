function validateCategoryForm() {
    var name = document.getElementById("cat_name").value;

    if (name.trim() == "") {
        alert("Error: Category Name cannot be empty.");
        return false;
    }

    return true; 
}

function confirmDelete() {
    return confirm("Are you sure you want to delete this record? This action cannot be undone.");
}