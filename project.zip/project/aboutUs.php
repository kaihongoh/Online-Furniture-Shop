<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Ikea4U</title>
    <link rel="stylesheet" href="css/template.css">
    <link rel="stylesheet" href="css/about_us.css">
    
</head>
<body>
    <?php include_once 'includes/header.php'; ?>
<div class="about-page">
    <div class="about-header">
        <h2>About us</h2>
        <p>
            Welcome to Ikea4U - Your first choice online furniture destination. 
            We're a dedicated team passionate about bringing quality furniture to your home.
        </p>
        <br>
        <p style="text-align:justify;">Explore the IKEA story here and learn more about our heritage and the events that shaped us.</p>
    </div>

    <div class="mission-section">
                <h2>Our Mission & Vision</h2>
                <div class="mission-content">
                    <div class="mission-item">
                        <h3>Our Mission</h3>
                        <p>To provide an exceptional online furniture shopping experience with quality products, excellent customer service, and innovative solutions.</p>
                    </div>
                    <div class="mission-item">
                        <h3>Our Vision</h3>
                        <p>To become the leading online furniture platform in Malaysia, known for reliability, innovation, and customer satisfaction.</p>
                    </div>
                </div>
    </div>

    <div class="team-info">
        <h2>Our Team</h2>
                <p>
                    We are a group of passionate students from Multimedia University, 
                    working together to bring you the best online furniture shopping experience. 
                    Each team member brings unique skills and dedication to make Ikea4U a success.
                </p>
    </div>
        
    <div class="member-card">
        <img src="image\handsome boy.jpeg" alt="member 1">
        <div class="member-info">
            <h3 class="member-name">OH KAI HONG</h3>
            <p class="member-role">Team leader & full stack developer</p>
            <p class="member-bio">
                Responsible for overall project coordination and backend development. 
                Specializes in PHP and database management.
            </p>
            <div class="member-contact">
                <div class="contact-item">
                    <i class="email">Email: OH.KAI.HONG@student.mmu.edu.my</i>
                </div>
                <div class="contact-item">
                    <i class="phone">Phone: 017-369-3757</i>
                </div>
                <div class="contact-item">
                    <i class="task">Role: Project management, backend development</i>
                </div>
            </div>
        </div>
    </div>

        <div class="member-card">
        <img src="image\heng rui.jpeg" alt="member 2">
        <div class="member-info">
            <h3 class="member-name">KOK HENG RUI</h3>
            <p class="member-role">Frontend developer & UI/UX designer</p>
            <p class="member-bio">
                Creates beautiful and responsive user interfaces. 
                Focuses on user experience and frontend functionality.
            </p>
            <div class="member-contact">
                <div class="contact-item">
                    <i class="email">Email: KOK.HENG.RUI@student.mmu.edu.my</i>
                </div>
                <div class="contact-item">
                    <i class="phone">Phone: 018-779-7190</i>
                </div>
                <div class="contact-item">
                    <i class="task">Role: UI/UX design, frontend development</i>
                </div>
            </div>
        </div>
    </div>

        <div class="member-card">
        <img src="image\wey hong.jpeg" alt="member 3">
        <div class="member-info">
            <h3 class="member-name">LO WEY HONG</h3>
            <p class="member-role">Backend developer & database admin</p>
            <p class="member-bio">
                Manages database architecture and server-side logic. 
                Ensures data security and system performance.
            </p>
            <div class="member-contact">
                <div class="contact-item">
                    <i class="email">Email: LO.WEY.HONG@student.mmu.edu.my</i>
                </div>
                <div class="contact-item">
                    <i class="phone">Phone: 016-214-6822</i>
                </div>
                <div class="contact-item">
                    <i class="task">Role: Database Management, API development</i>
                </div>
            </div>
        </div>
    </div>

    <div class="contact-section">
        <p>Have questions about our project or team? We'd love to hear from you!</p>
    </div>
        


</div>
    <?php include_once 'includes/footer.php'; ?>
</body>
</html>