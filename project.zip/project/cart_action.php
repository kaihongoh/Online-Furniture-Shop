<?php
// cart_action.php
session_start();
include 'includes/config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?error=login_required");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'] ?? 0;
    $quantity = $_POST['quantity'] ?? 1;
    
    // Validate quantity
    if ($quantity <= 0) {
        header("Location: product_details.php?id=$product_id&error=invalid_quantity");
        exit();
    }
    
    // Check product exists and get stock
    $stmt = $conn->prepare("SELECT Product_Stock FROM product WHERE Product_ID = ? AND status = 'Active'");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        header("Location: product_details.php?id=$product_id&error=not_found");
        exit();
    }
    
    $product = $result->fetch_assoc();
    $stock = $product['Product_Stock'];
    
    // Check if enough stock
    if ($quantity > $stock) {
        header("Location: product_details.php?id=$product_id&error=insufficient_stock");
        exit();
    }
    
    // Add to database cart
    $stmt = $conn->prepare("
        INSERT INTO cart (User_ID, Product_ID, Quantity) 
        VALUES (?, ?, ?) 
        ON DUPLICATE KEY UPDATE Quantity = Quantity + VALUES(Quantity)
    ");
    $stmt->bind_param("iii", $_SESSION['user_id'], $product_id, $quantity);
    
    if ($stmt->execute()) {
        // Check if this was an update (item already existed in cart)
        $checkStmt = $conn->prepare("SELECT Quantity FROM cart WHERE User_ID = ? AND Product_ID = ?");
        $checkStmt->bind_param("ii", $_SESSION['user_id'], $product_id);
        $checkStmt->execute();
        $cartQty = $checkStmt->get_result()->fetch_assoc()['Quantity'];
        
        $successType = ($cartQty > $quantity) ? 'updated' : 'added';
        header("Location: product_details.php?id=$product_id&success=$successType");
    } else {
        header("Location: product_details.php?id=$product_id&error=server_error");
    }
    exit();
}

// If not a POST request or missing data
header("Location: catalogue.php");
exit();