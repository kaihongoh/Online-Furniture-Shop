<?php
session_start();

// Simple admin check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

include 'includes/config.php';

// Initialize success message
$success_msg = '';
$error_msg = '';

// --- UPDATE ORDER STATUS (POST HANDLING) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_btn'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = $conn->real_escape_string($_POST['status_choice']);
    
    // Validate the status
    $allowed_statuses = ['Pending', 'Shipped', 'Completed', 'Cancelled'];
    if (!in_array($new_status, $allowed_statuses)) {
        $error_msg = "Invalid order status selected.";
    } else {
        $update_sql = "UPDATE orders SET Order_Status = '$new_status' WHERE Order_ID = $order_id";
        
        if ($conn->query($update_sql)) {
            $success_msg = "Order #$order_id status updated to $new_status successfully!";
        } else {
            $error_msg = "Error updating order status: " . $conn->error;
        }
    }
}

// --- FETCH DATA ---
$sql = "SELECT 
            orders.Order_ID, orders.Total_Amount, orders.Order_Status, orders.Order_Date,
            users.User_ID, users.User_Name,
            SUM(order_items.Quantity) as Total_Item_Count,
            GROUP_CONCAT(CONCAT('<b>', product.Product_Name, '</b> <span class=\'text-muted small\'>x', order_items.Quantity, '</span>') SEPARATOR '<br>') as Item_List
        FROM orders
        LEFT JOIN users ON orders.User_ID = users.User_ID
        LEFT JOIN order_items ON orders.Order_ID = order_items.Order_ID
        LEFT JOIN product ON order_items.Product_ID = product.Product_ID
        GROUP BY orders.Order_ID
        ORDER BY orders.Order_Date DESC";
        
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>  
    <meta charset="UTF-8">
    <title>Manage Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/admin_sidebar.css">
    <link rel="stylesheet" href="css/manage_orders.css">

</head>
<body>

  <?php include 'admin_sidebar.php'; ?>
  
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-dark">Manage Orders</h2>
        </div>

        <!-- Success/Error Messages -->
        <?php if (!empty($success_msg)): ?>
            <div class="alert-success">
                <i class="bi bi-check-circle-fill"></i>
                <?php echo htmlspecialchars($success_msg); ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($error_msg)): ?>
            <div class="alert-danger">
                <i class="bi bi-exclamation-triangle-fill"></i>
                <?php echo htmlspecialchars($error_msg); ?>
            </div>
        <?php endif; ?>

        <div class="table-card">
            <div class="table-responsive">
                <?php if ($result && $result->num_rows > 0): ?>
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th class="col-date">Date Ordered</th>
                            <th class="col-items">Items</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th class="col-action">Update</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <?php 
                                // Determine badge color based on status
                                $badgeClass = "bg-soft-warning";
                                if($row['Order_Status']=='Shipped') $badgeClass = "bg-soft-primary";
                                if($row['Order_Status']=='Completed') $badgeClass = "bg-soft-success";
                                if($row['Order_Status']=='Cancelled') $badgeClass = "bg-soft-danger";
                                
                                // Format Date
                                $order_date = strtotime($row['Order_Date']);
                                $nice_date = date("d-M-Y", $order_date);
                                $nice_time = date("h:i A", $order_date);
                            ?>
                        <tr>
                            <td class="fw-bold text-dark">#<?php echo $row['Order_ID']; ?></td>
                            
                            <td>
                                <div class="fw-bold text-dark"><?php echo htmlspecialchars($row['User_Name']); ?></div>
                                <div class="text-muted small">ID: <?php echo $row['User_ID']; ?></div>
                            </td>

                            <td>
                                <div class="fw-bold text-dark"><?php echo $nice_date; ?></div>
                                <div class="text-muted small"><?php echo $nice_time; ?></div>
                            </td>

                            <td class="small text-secondary">
                                <?php echo $row['Item_List'] ?: '<span class="text-danger fst-italic">No items linked</span>'; ?>
                            </td>

                            <td class="fw-bold text-dark">RM <?php echo number_format($row['Total_Amount'], 2); ?></td>
                            
                            <td>
                                <span class="badge rounded-pill <?php echo $badgeClass; ?> status-badge p-2">
                                    <?php echo strtoupper($row['Order_Status']); ?>
                                </span>
                            </td>

                            <td>
                                <form method="POST" action="" class="status-form">
                                    <input type="hidden" name="order_id" value="<?php echo $row['Order_ID']; ?>">
                                    <div class="input-group input-group-sm">
                                        <select name="status_choice" class="form-select form-select-sm">
                                            <option value="Pending" <?php echo $row['Order_Status']=='Pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="Shipped" <?php echo $row['Order_Status']=='Shipped' ? 'selected' : ''; ?>>Shipped</option>
                                            <option value="Completed" <?php echo $row['Order_Status']=='Completed' ? 'selected' : ''; ?>>Completed</option>
                                            <option value="Cancelled" <?php echo $row['Order_Status']=='Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                        </select>
                                        <button type="submit" name="update_btn" class="btn btn-dark btn-sm">
                                            <i class="bi bi-check-lg"></i> Update
                                        </button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="p-5 text-center text-muted">
                    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                    No orders found in the database.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
        // Auto-hide success message after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            const successAlert = document.querySelector('.alert-success');
            if (successAlert) {
                setTimeout(function() {
                    successAlert.style.transition = 'opacity 0.5s';
                    successAlert.style.opacity = '0';
                    setTimeout(function() {
                        successAlert.style.display = 'none';
                    }, 500);
                }, 5000);
            }
            
            // Auto-hide error message after 10 seconds
            const errorAlert = document.querySelector('.alert-danger');
            if (errorAlert) {
                setTimeout(function() {
                    errorAlert.style.transition = 'opacity 0.5s';
                    errorAlert.style.opacity = '0';
                    setTimeout(function() {
                        errorAlert.style.display = 'none';
                    }, 500);
                }, 10000);
            }
            
            // Scroll to top of table after update to see the message
            if (successAlert || errorAlert) {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    </script>
</body>
</html>