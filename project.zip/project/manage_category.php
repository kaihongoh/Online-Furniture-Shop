<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit;
}

include 'includes/config.php';

if (isset($_POST['add_category'])) {
    $cat_name = $_POST['category_name'];

    if (!empty($cat_name)) {
        $stmt = $conn->prepare("INSERT INTO category (Category_Name, Status) VALUES (?, 'Active')");
        $stmt->bind_param("s", $cat_name);
        $stmt->execute();
        echo "<script>alert('Category added successfully!');</script>";
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM category WHERE Category_ID=$id");
    header("Location: manage_category.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Categories - Furniture Shop</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <link rel="stylesheet" href="css/admin_sidebar.css">
    <link rel="stylesheet" href="css/admin.css">
    
    <script src="js/admin_script.js" defer></script>
</head>
<body class="bg-light">

<?php include 'admin_sidebar.php'; ?>

<div class="main-content p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-dark">Manage Categories</h2>
    </div>

    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-bold"><i class="bi bi-plus-square"></i> Add New Category</h5>
                </div>
                <div class="card-body">
                    <form action="" method="POST" onsubmit="return validateCategoryForm()">
                        <div class="mb-3">
                            <label class="form-label text-secondary">Category Name</label>
                            <input type="text" name="category_name" id="cat_name" class="form-control" placeholder="e.g. Sofas, Tables">
                        </div>
                        <button type="submit" name="add_category" class="btn btn-primary w-100">
                            <i class="bi bi-check-lg"></i> Add Category
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-3">
                    <h5 class="mb-0 fw-bold"><i class="bi bi-list-ul"></i> Existing Categories</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover table-striped mb-0 align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th class="py-3 ps-4" style="width: 10%;">ID</th>
                                    <th class="py-3">Name</th>
                                    <th class="py-3">Status</th> 
                                    <th class="py-3 text-end pe-4">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $result = $conn->query("SELECT * FROM category");
                                if ($result && $result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>
                                                <td class='ps-4 fw-bold'>{$row['Category_ID']}</td>
                                                <td class='fw-bold'>{$row['Category_Name']}</td>
                                                <td><span class='badge bg-success'>{$row['Status']}</span></td>
                                                <td class='text-end pe-4'>
                                                    <a href='manage_category.php?delete={$row['Category_ID']}' onclick=\"return confirmDelete()\" class='btn btn-sm btn-outline-danger'>
                                                        <i class='bi bi-trash3-fill'></i> Delete
                                                    </a>
                                                </td>
                                              </tr>";
                                    }
                                } else {
                                     echo "<tr><td colspan='4' class='text-center py-4 text-muted'>No categories found.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
