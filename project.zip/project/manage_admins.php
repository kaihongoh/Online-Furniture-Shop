<?php
session_start();

// Superadmin check - only superadmin can access
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true || $_SESSION['admin_role'] !== 'super_admin') {
    header("Location: admin_dashboard.php");
    exit;
}

include 'includes/config.php';

// Initialize messages
$success_msg = '';
$error_msg = '';

// --- CREATE NEW ADMIN ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_admin'])) {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $role = $_POST['role'] ?? 'admin';
    
    // Validation
    if (empty($username) || empty($password) || empty($full_name)) {
        $error_msg = "Username, password, and full name are required.";
    } else {
        // Check if username already exists
        $check_stmt = $conn->prepare("SELECT admin_id FROM admin_users WHERE username = ?");
        $check_stmt->bind_param("s", $username);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $error_msg = "Username already exists.";
        } else {
            // Generate next admin ID
            $id_result = $conn->query("SELECT MAX(CAST(SUBSTRING(admin_id, 2) AS UNSIGNED)) as max_id FROM admin_users");
            $max_id = $id_result->fetch_assoc()['max_id'] ?? 0;
            $next_id = 'A' . str_pad($max_id + 1, 3, '0', STR_PAD_LEFT);
            
            // Insert new admin
            $insert_stmt = $conn->prepare(
                "INSERT INTO admin_users (admin_id, username, password, full_name, email, role) 
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            $insert_stmt->bind_param("ssssss", $next_id, $username, $password, $full_name, $email, $role);
            
            if ($insert_stmt->execute()) {
                $success_msg = "Admin account created successfully! Admin ID: $next_id";
            } else {
                $error_msg = "Error creating admin account: " . $conn->error;
            }
            $insert_stmt->close();
        }
        $check_stmt->close();
    }
}

// --- FETCH ALL ADMINS ---
$admins_sql = "SELECT 
    admin_id, 
    username, 
    full_name, 
    email, 
    role,
    DATE_FORMAT(created_at, '%d-%b-%Y %h:%i %p') as created_date,
    DATE_FORMAT(last_login, '%d-%b-%Y %h:%i %p') as last_login_formatted
    FROM admin_users 
    ORDER BY created_at DESC";
$admins_result = $conn->query($admins_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admins - Ikea4U</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/admin_sidebar.css">
    <link rel="stylesheet" href="css/manage_admins.css">
</head>
<body>
    <?php include 'admin_sidebar.php'; ?>
    
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="fw-bold text-dark">Manage Administrators</h2>
            <div class="badge bg-warning text-dark p-2">
                <i class="bi bi-shield-check me-1"></i> Superadmin Access
            </div>
        </div>

        <!-- Success/Error Messages -->
        <?php if (!empty($success_msg)): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle-fill me-2"></i>
                <?php echo htmlspecialchars($success_msg); ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($error_msg)): ?>
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?php echo htmlspecialchars($error_msg); ?>
            </div>
        <?php endif; ?>

        <!-- Create New Admin Form -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-person-plus me-2"></i> Create New Admin Account</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="username" class="form-label">Username *</label>
                            <input type="text" class="form-control" id="username" name="username" required 
                                   placeholder="Enter username">
                        </div>
                        <div class="col-md-6">
                            <label for="password" class="form-label">Password *</label>
                            <input type="password" class="form-control" id="password" name="password" required 
                                   placeholder="Enter password">
                        </div>
                        <div class="col-md-6">
                            <label for="full_name" class="form-label">Full Name *</label>
                            <input type="text" class="form-control" id="full_name" name="full_name" required 
                                   placeholder="Enter full name">
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" 
                                   placeholder="Enter email address">
                        </div>
                        <div class="col-md-6">
                            <label for="role" class="form-label">Role</label>
                            <select class="form-select" id="role" name="role">
                                <option value="admin">Admin</option>
                                <option value="super_admin">Super Admin</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <button type="submit" name="create_admin" class="btn btn-primary">
                                <i class="bi bi-person-add me-1"></i> Create Admin Account
                            </button>
                            <small class="text-muted ms-2">* Required fields</small>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Admins List -->
        <div class="card">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0"><i class="bi bi-people me-2"></i> All Admin Accounts</h5>
            </div>
            <div class="card-body">
                <?php if ($admins_result && $admins_result->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Admin ID</th>
                                    <th>Username</th>
                                    <th>Full Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Created Date</th>
                                    <th>Last Login</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($admin = $admins_result->fetch_assoc()): ?>
                                    <tr>
                                        <td class="fw-bold"><?php echo htmlspecialchars($admin['admin_id']); ?></td>
                                        <td><?php echo htmlspecialchars($admin['username']); ?></td>
                                        <td><?php echo htmlspecialchars($admin['full_name']); ?></td>
                                        <td><?php echo htmlspecialchars($admin['email'] ?: 'N/A'); ?></td>
                                        <td>
                                            <?php 
                                                $role_badge = "bg-primary";
                                                if ($admin['role'] == 'super_admin') $role_badge = "bg-warning text-dark";
                                                if ($admin['role'] == 'manager') $role_badge = "bg-info";
                                                if ($admin['role'] == 'support') $role_badge = "bg-secondary";
                                            ?>
                                            <span class="badge <?php echo $role_badge; ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $admin['role'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo $admin['created_date']; ?></td>
                                        <td><?php echo $admin['last_login_formatted'] ?: 'Never'; ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-people display-1 text-muted"></i>
                        <h4 class="text-muted mt-3">No admin accounts found</h4>
                        <p class="text-muted">Create your first admin account using the form above.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
        // Auto-hide alerts after 5 seconds
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(alert => {
                    alert.style.transition = 'opacity 0.5s';
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 500);
                });
            }, 5000);
        });
    </script>
</body>
</html>