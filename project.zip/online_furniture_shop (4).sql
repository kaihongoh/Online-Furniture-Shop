-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2026 at 06:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_furniture_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `admin_id` varchar(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`admin_id`, `username`, `password`, `full_name`, `email`, `role`, `created_at`, `last_login`, `is_active`) VALUES
('A001', 'superadmin', 'Abc123', 'sadmin\r\n', 'superadmin@ikea4u.com', 'super_admin', '2026-02-07 08:48:51', '2026-02-08 14:40:37', 1),
('A002', 'admin1', 'Abc123', 'John Doe', 'john@ikea4u.com', 'admin', '2026-02-07 08:48:51', '2026-02-07 10:08:26', 1),
('A003', 'handsome boy', 'Abc123', 'handsome boy', '', 'admin', '2026-02-07 17:15:21', '2026-02-08 17:05:12', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `User_ID` int(11) NOT NULL,
  `Product_ID` int(11) NOT NULL,
  `Quantity` int(11) DEFAULT 1,
  `Added_Date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`User_ID`, `Product_ID`, `Quantity`, `Added_Date`) VALUES
(11, 2, 1, '2026-02-08 15:03:03');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Category_ID` int(11) UNSIGNED NOT NULL COMMENT 'primary key',
  `Category_Name` varchar(50) DEFAULT NULL COMMENT 'Sofa, cahir, table',
  `Status` enum('Active','Inactive') NOT NULL DEFAULT 'Active' COMMENT 'Show or hide category',
  `Created_At` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Record creation time'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Category_ID`, `Category_Name`, `Status`, `Created_At`) VALUES
(1, 'Armchairs', 'Active', '2026-01-24 09:58:23'),
(2, 'Sofas', 'Active', '2026-01-24 09:58:23'),
(3, 'Storage boxes&baskets', 'Active', '2026-01-24 10:02:27'),
(4, 'Beds & Mattresses', 'Active', '2026-02-07 10:52:33'),
(5, 'Kitchen Kabinets', 'Active', '2026-02-07 10:53:05'),
(6, 'Laundry & Cleaning', 'Active', '2026-02-07 10:53:35'),
(7, 'Home Decoration', 'Active', '2026-02-07 10:53:52');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Order_ID` int(11) UNSIGNED NOT NULL,
  `User_ID` int(11) UNSIGNED NOT NULL,
  `Total_Amount` decimal(10,2) NOT NULL,
  `Order_Status` enum('Pending','Paid','Shipped','Completed','Cancelled') DEFAULT 'Pending',
  `Order_Date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`Order_ID`, `User_ID`, `Total_Amount`, `Order_Status`, `Order_Date`) VALUES
(1, 1, 719.50, 'Completed', '2026-02-01 06:53:30'),
(2, 1, 120.50, 'Completed', '2026-02-02 06:53:30'),
(3, 1, 250.00, 'Completed', '2026-02-03 06:53:30'),
(4, 1, 1568.50, 'Completed', '2026-02-03 07:26:32'),
(5, 1, 719.50, 'Shipped', '2026-02-03 07:27:16'),
(6, 1, 849.00, 'Completed', '2026-02-03 07:30:20'),
(7, 1, 599.00, 'Pending', '2026-02-03 07:35:51'),
(8, 1, 719.50, 'Pending', '2026-02-04 14:54:46'),
(9, 1, 719.50, 'Completed', '2026-02-04 15:05:23'),
(10, 2, 10.00, 'Pending', '2026-02-08 13:49:10'),
(11, 10, 14699.00, 'Completed', '2026-02-08 14:08:36'),
(12, 2, 69.00, 'Pending', '2026-02-08 16:53:15'),
(13, 2, 69.00, 'Pending', '2026-02-08 16:58:28'),
(14, 2, 20.00, 'Completed', '2026-02-08 17:02:50');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `ID` int(11) UNSIGNED NOT NULL,
  `Order_ID` int(11) UNSIGNED NOT NULL,
  `Product_ID` int(11) UNSIGNED NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`ID`, `Order_ID`, `Product_ID`, `Quantity`, `Price`) VALUES
(1, 1, 1, 1, 599.00),
(2, 1, 2, 1, 120.50),
(3, 2, 2, 1, 120.50),
(4, 3, 3, 1, 250.00),
(5, 4, 1, 2, 599.00),
(6, 4, 2, 1, 120.50),
(7, 4, 3, 1, 250.00),
(8, 5, 1, 1, 599.00),
(9, 5, 2, 1, 120.50),
(10, 6, 1, 1, 599.00),
(11, 6, 3, 1, 250.00),
(12, 7, 1, 1, 599.00),
(13, 8, 1, 1, 599.00),
(14, 8, 2, 1, 120.50),
(15, 9, 1, 1, 599.00),
(16, 9, 2, 1, 120.50),
(17, 10, 6, 2, 5.00),
(18, 11, 26, 1, 14699.00),
(19, 12, 2, 1, 69.00),
(20, 13, 2, 1, 69.00),
(21, 14, 4, 2, 10.00);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_ID` int(11) NOT NULL,
  `Product_Name` varchar(40) DEFAULT NULL,
  `Category_ID` int(11) UNSIGNED DEFAULT NULL,
  `Product_Picture` text DEFAULT NULL,
  `Product_Price` decimal(10,2) DEFAULT NULL,
  `Product_Stock` int(11) DEFAULT NULL,
  `Product_Description` text DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `Dis_Price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_ID`, `Product_Name`, `Category_ID`, `Product_Picture`, `Product_Price`, `Product_Stock`, `Product_Description`, `status`, `Dis_Price`) VALUES
(2, 'BLODBJÖRK Vase', 7, '698746f8e1906.avif', 69.00, 5, 'Diameter: 18 cm\r\nHeight: 25 cm\r\n\r\nA calm and romantic feel. This vase comes in a soft light-pink colour and has a narrow opening that suits both large bouquets and single flowers or lovely branches. Blends in well with many decor styles.', 'Active', NULL),
(3, 'SMÅSTAD Loft bed frame', 4, '69874fadb4509.avif', 2320.00, 29, 'Loft bed frame w desk and storage, white\r\nMattress width: 90 cm\r\nMattress length: 200 cm\r\nMax. thickness, mattress: 20 cm\r\nHeight: 182 cm\r\nHeight under loft bed: 142 cm\r\nWidth: 207 cm\r\nDepth: 104 cm\r\nDesk length: 148 cm\r\nDesk width: 60 cm\r\nDesk height: 73 cm\r\nMax. load: 100 kg\r\n\r\nAn extra room isn’t always an option when space is limited at home. But there are other solutions. Here’s room for sleeping, studying, storing, playing and chilling that only takes up 2m2 of space.', 'Active', NULL),
(4, 'DVALA Pillowcase', 4, '698755309c616.avif', 10.00, 30, 'DVALA pillowcase is made from 100% cotton that breathes and absorbs moisture so you experience an even sleep temperature all night. The material gets softer and cosier with each wash.', 'Active', NULL),
(5, 'JÄLL Laundry Bag', 6, '698750c516832.avif', 25.00, 22, 'Laundry bag with stand, white\r\nLength: 42 cm\r\nWidth: 43 cm\r\nHeight: 60 cm\r\nVolume: 50 l\r\nMax. load: 8 kg\r\n\r\nIt’s lightweight and folds up so you can carry it to the washing machine, stow it in a closet – or hang it on a hook. It holds up to 8 kg of laundry – so relax, it’s not full just yet.', 'Active', NULL),
(6, 'BÄSTIS Lint roller', 6, '69875138b156c.avif', 5.00, 43, 'This lint roller has a whopping 40 sticky sheets that remove fur hair, dust and lint from clothes, furniture and car seats.', 'Active', NULL),
(7, 'VÅGSTRANDA Pocket sprung mattress', 4, '69875641ad562.avif', 1899.00, 29, 'Length: 200 cm\r\nWidth: 150 cm\r\nThickness: 28 cm\r\n\r\nAn extra-firm 28 cm high innovative double layer pocket spring mattress. You get ultimate comfort and perfect support from comfort zones that adjust to your body. A generous layer of foam adds to the feel!', 'Active', NULL),
(8, 'PEPPRIG Dust pan and brush', 6, '698753034c686.avif', 9.00, 7, 'This lightweight dust pan and brush set is good for cleaning crumbs and spills. Convenient to have close by for those everyday messes and easy to store since the brush attaches to the pan.', 'Active', NULL),
(9, 'SLIBB Hang dryer 24 clothes pegs', 6, '698751f5ef3b5.avif', 32.00, 28, 'Lots of laundry and limited space? Here you have a smart solution – a foldable hanging dryer with 24 clothes pegs. Perfect to hang up and use to dry socks, underwear and small washcloths in a small area.', 'Active', NULL),
(10, 'SÖDERHAMN Armchair', 1, '698759f7e0c3d.avif', 1445.00, 18, 'If you like the stylish airy look, you have to try the deep generous seats. Create your own personal combination of SÖDERHAMN sofa, then sit down and relax – by yourself or together with the whole family.', 'Active', NULL),
(11, 'SANDLÖPARE Storage trunk', 3, '6987538c84473.avif', 69.00, 32, 'Savannah expeditions require a lot of gear! Pack everything in this trunk with stickers that show it has been on a trip before. Store it under the bed or sofa when the adventure is over for the time being.', 'Active', NULL),
(12, 'IDANÄS Upholstered Ottoman Bed', 4, '69874c009a898.avif', 2299.00, 25, 'The sloping headboard and soft upholstery make IDANÄS ottoman bed extra comfortable. Classic button detailing is timeless, while the space under the bed adds generous everyday storage.', 'Active', NULL),
(13, 'SKÅDIS Pegboard combination', 7, '698757eee9009.avif', 140.00, 19, 'A perfect way to get organised and keep smaller items close at hand anywhere in the home. Create your own combination of SKÅDIS pegboard and SKÅDIS accessories or choose this ready-made combination.', 'Active', NULL),
(14, 'LINDBYN Mirror', 7, '6987573443837.avif', 179.00, 16, 'By decorating with mirrors, you add depth to a room and give it more life. The round LINDBYN mirror has a soft expression and the black frame and neat design feel elegant.', 'Active', NULL),
(15, 'TERTIAL Work lamp', 7, '6987498ec166d.avif', 55.00, 32, 'Work lamp, dark grey\r\n\r\nTERTIAL work lamp was introduced in our range in 1998. The classic, steel design with adjustable arm and head makes it a perfect choice if you are looking for a flexible and effective reading light.', 'Active', NULL),
(16, 'STRANDMON Wing Chair', 1, '69873cfd67799.avif', 699.00, 21, 'STRANDMON Wing chair, Nordvalla dark grey', 'Active', NULL),
(17, 'LANDSKRONA Armchair', 1, '69873e315f265.avif', 3090.00, 20, 'Armchair, Grann/Bomstad golden-brown/wood', 'Active', NULL),
(18, 'SOPPROT Pull-out Storage Unit', 3, '6987450094d50.avif', 59.00, 4, 'Pull-out storage unit, transparent white\r\nWidth: 17 cm\r\nDepth: 45.6 cm\r\nHeight: 20.5 cm\r\n\r\nComes in various sizes and is easy to open, even if you stack several on top of each other. Combine them as you like and let them take care of your big and small things.', 'Active', NULL),
(19, 'GLOSTAD 3-seat Sofa', 2, '69873f867ba86.avif', 499.00, 19, '3-seat sofa, Knisa dark grey', 'Active', NULL),
(20, 'METOD Wall Cabinet', 5, '6987440d34fe9.avif', 585.00, 7, 'Wall cabinet with 2 glass doors, white/Bodbyn grey\r\nWidth: 80.0 cm\r\nSystem, depth: 37 cm\r\nDepth: 38.9 cm\r\nHeight: 40.0 cm', 'Active', NULL),
(21, 'NOLLÅTTA Alarm Clock', 7, '698747da04588.avif', 49.00, 13, 'Clear numbers that show the time, adjustable brightness and a signal that is guaranteed to wake you up when it\'s time to get up. What more could you ask for from a modern alarm clock?', 'Active', NULL),
(22, 'VIMLE Corner Sofa', 2, '69874032189e4.avif', 6390.00, 8, 'Corner sofa, 5-seat, with chaise longue and gunnared beige', 'Active', NULL),
(23, 'LANDSKRONA 4-seat sofa', 2, '6987411ce1dfc.avif', 5745.00, 31, '4-seat sofa, with chaise longue/Gunnared dark grey/metal', 'Active', NULL),
(24, 'METOD cabinet', 5, '6987421be1cb8.avif', 1568.00, 22, 'High cabinet with cleaning interior, white/Aspudden light grey, 60x60x220 cm', 'Active', NULL),
(25, 'SKOLÄST Waste bin', 5, '6987430d2b0dd.avif', 18.00, 65, 'Waste bin for cabinet with door, light grey\r\nLength: 23 cm\r\nWidth: 16 cm\r\nHeight: 22 cm\r\nVolume: 3.3 l', 'Active', NULL),
(26, 'JÄTTEBO U-shaped sofa', 2, '6987593b58f2f.avif', 14699.00, 48, 'U-shaped sofa, 7-seat, with chaise longue, right with headrests/Tonerud grey.\r\nEnjoy long movie nights and comfy socialising with friends in JÄTTEBO modular sofa. Use this comfy combination as it is – or create a customised sofa for you and your home with the planning tool.', 'Active', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `SubCategory_ID` int(11) NOT NULL,
  `Category_ID` int(11) UNSIGNED NOT NULL,
  `SubCategory_Name` varchar(100) NOT NULL,
  `Status` enum('Active','Inactive') NOT NULL,
  `Created_At` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_ID` int(11) UNSIGNED NOT NULL,
  `User_Code` varchar(20) DEFAULT NULL,
  `User_Name` varchar(30) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phoneNumber` varchar(15) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `security_question` varchar(255) NOT NULL,
  `security_answer` varchar(255) NOT NULL,
  `role` enum('customer','admin') DEFAULT 'customer',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_ID`, `User_Code`, `User_Name`, `email`, `phoneNumber`, `state`, `postcode`, `address`, `password`, `security_question`, `security_answer`, `role`, `created_at`, `updated_at`) VALUES
(2, NULL, 'james', 'james@gmail.com', '012-443-3423', 'Terengganu', '11111', 'melaka, efnefweofefnwf', '$2y$10$yEv0/Sr0tPSHHNmaXCtPkOtqEXV80Kknx7XEHpu/x1wNaxshkdv0S', 'Favourite movie?', '$2y$10$Kymrwk1vMyr9nMcSMVQKSe320XxkFomxi29T2sF9AMIE4uhqnjSpq', 'customer', '2026-01-29 08:56:59', '2026-02-08 16:52:41'),
(3, NULL, 'james2', 'james1@gmail.com', '111-222-1111', NULL, NULL, 'melaka ceewewefe', '$2y$10$ivU8QjK.ZR8t8E9PRLtO8u8wAN4wPEcQNcPW5A/RJtZak0IKZe8s6', 'What is your mother\'s maiden name?', '$2y$10$Rq5ZHKS9iArx0LHIYxyUgu9F3j6aiI2ZgYtAkQgXf1R.QAkGCZuby', 'customer', '2026-01-29 09:11:19', '2026-02-07 09:09:50'),
(4, NULL, 'wrrg', 'w@gmail.com', '111-111-3333', NULL, NULL, 'melaka, melaka raya', '$2y$10$fa.AkQldRN4C8qQAXKV7G.6AwIPRMZZmSAOs4mbn1.F30z2M0gphq', 'What is your mother maiden name?', '$2y$10$gqIlG00CRl3vHhEY2khVQuhmudflKOURpocMx9iJD5Fvd4GevDufW', 'customer', '2026-01-29 09:18:31', '2026-02-07 09:09:59'),
(5, NULL, '12', 'Brew93gee@turniti.com', '111-222-3333', 'Melaka', '11111', '11, bukit beruang, multimedia university', '$2y$10$mtyDy.OUdS5hb1j2qDogY.593GKleXK8wwNye/bdoZQcTTpOXKi/S', 'What is your favorite movie?', '$2y$10$mrDIT7isooC.8hUBuCACUemG7HEWyylAh9YQwUgO0RbXsZN3SKT7q', 'customer', '2026-01-31 15:28:45', '2026-02-07 09:10:10'),
(6, NULL, 'da', 'da@gmail.com', '111-111-1111', 'Pahang', '11111', 'melaka grgbr 发', '$2y$10$JzYJS410TcOljP/nm5kzrO9EBBn5OVXhRbxLHDRAxzMDyz5fhzjCe', 'What is your favorite color?', '$2y$10$0zzECB7qy7jN2/1vS4wf.OJuiMCodwHvTKHnvaIQ8CuPC/NP5/L0i', 'customer', '2026-01-31 15:35:37', '2026-01-31 15:35:37'),
(7, NULL, 'fr', 'OH.KAI.HONG@student.mmu.edu.my', '012-222-3232', 'Penang', '10000', 'georgetown', '$2y$10$0AAL8rRjODKdLH6STPeuM.yX6wQePGPO16/KHMb8CEp/wOJzM1Zrq', 'What is your favorite color?', '$2y$10$c5AFCAsc3cgJ7rvb2TEEZebHu7MOp4STHuLdGTuGqWLXLD8oAu.Am', 'customer', '2026-02-01 14:36:33', '2026-02-01 14:39:27'),
(8, NULL, 'bryan', 'bryan21@gmail.com', '012-333-2222', 'Malacca', '10000', 'bukit beruang', '$2y$10$nx2P/dSzfYxB5dFAJrh2gOMux/GaZAHlZHmKKgzwjJwrPyo9LG3RS', 'What is your mother maiden name?', '$2y$10$BGFBL0VZ6wSJzH2OrxS90.wmcbsqQ64bZ6JSvfU7pow4giCBNRRXS', 'customer', '2026-02-05 06:30:57', '2026-02-05 06:34:47'),
(9, NULL, 'hy', 'hy@gmail.com', '111-232-1111', 'Kelantan', '12121', 'freghrgrgeergerg', 'abc123', 'What is your favorite movie?', '$2y$10$I.S63.1zrYyRBH7Mb2T/5uEbbq4rIhMkB75.YiQK.UUuJ4fjlEkAi', 'admin', '2026-02-07 08:58:56', '2026-02-07 13:06:21'),
(10, NULL, 'hengrui', 'hengrui@gmail.com', '016-222-4857', 'Sabah', '90099', 'sabah , supering', '$2y$10$xZk2TA2MBorwKqEIsJA.SuAOFfjHL.ScjhUGfx0rnZRP3uzAGGx9u', 'What is your mother maiden name?', '$2y$10$5WXGnN5e5yNP1/vkbAD3Cen9aiHP2HiDqG3FduJFl53LQSsyoywOW', 'customer', '2026-02-08 14:05:56', '2026-02-08 14:11:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`User_ID`,`Product_ID`),
  ADD KEY `Product_ID` (`Product_ID`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Category_ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Order_ID`),
  ADD KEY `User_ID` (`User_ID`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Order_ID` (`Order_ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product_ID`),
  ADD KEY `Category_ID` (`Category_ID`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`SubCategory_ID`),
  ADD KEY `Category_ID` (`Category_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `unique_email` (`email`),
  ADD UNIQUE KEY `unique_user_name` (`User_Name`),
  ADD UNIQUE KEY `phoneNumber` (`phoneNumber`),
  ADD KEY `idx_user_code` (`User_Code`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Category_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'primary key', AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `Order_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Product_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `SubCategory_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `User_ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`Order_ID`) REFERENCES `orders` (`Order_ID`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `fk_product_category` FOREIGN KEY (`Category_ID`) REFERENCES `category` (`Category_ID`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD CONSTRAINT `fk_subcategories_category` FOREIGN KEY (`Category_ID`) REFERENCES `category` (`Category_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
